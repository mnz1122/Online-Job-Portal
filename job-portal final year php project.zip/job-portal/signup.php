<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Sign-Up Form</title>
  <!-- bootstrap file -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
  <!-- font awesome -->
  <link rel="stylesheet" href="css/all.css">
  <style>
    body {
      background-color: #fff;
      font-family: Arial, sans-serif;
    }

    .container {
      margin: 20px auto;
      max-width: 700px;
      background: #888;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    }

    h2 {
      margin-top: 0;
      text-align: center;
      color: #fff;
    }

    form {
      display: flex;
      flex-direction: column;
      align-items: left;
      margin-top: 10px;
      color:#888;
      font-size: 14px;
      font-weight: bold;
      margin-bottom: 5px;
    }

    input[type="text"],
    input[type="number"],
    input[type="password"],
    input[type="email"],
    input[type="date"] {
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type="submit"] {
      background-color: #4CAF50;
      color: white;
      padding: 12px 20px;
      margin-top: 20px;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      width: 100%;
    }

    label{
      color: #fff;
    }

    input[type="submit"]:hover {
      background-color: #45a049;
    }

    .login-link {
      margin-top: 20px;
      text-align: center;
      font-size: 17px;
      color: #fff;
    }

    .login-link a {
      color: blue;
      text-decoration: none;
    }

    .login-link a:hover{
      color: #fff;
      text-decoration: none;
    }
  </style>
</head>
<body>
<div class="container">
    <h2>Job Seeker Sign Up</h2>

    <!-- Form Start -->
    <form action="insert-sign-up.php" method="POST" name="signup form" id="form">
    
      <label for="fname">First name</label>
      <input type="text" id="fname" name="fname" placeholder="Enter your First Name" required>

      <label for="lname">last name</label>
      <input type="text" id="lname" name="lname" placeholder="Enter your last Name" required>

      <label for="username">Username</label>
      <input type="text" id="username" name="username" placeholder="Enter your username" required>

      <label for="email">Email</label>
      <input type="email" id="email" name="email" placeholder="Enter your email" required>

      <label for="password">Password</label>
      <input type="password" id="password" name="password" placeholder="Enter your password" required>

      <label for="confirm-password">Confirm Password</label>
      <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password" required>

      <label for="dob">Birth</label>
      <input type="date" id="dob" name="dob" placeholder="Enter your Phone Number" required>

      <label for="phone">Phone Number</label>
      <input type="number" id="number" name="number" placeholder="Enter your Phone Number" required>

      <input type="submit" name="submit" value="Sign Up"/>

    </form>
    <!-- Form End -->

    <div class="login-link">
      Already have an account? <a href="sign-in.php">Sign In</a>
    </div>
  </div>
</body>
</html>