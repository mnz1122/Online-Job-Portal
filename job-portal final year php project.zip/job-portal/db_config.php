<?php

$server_name = "localhost";
$user_name = "root";
$password = "";
$db_name = "db_job_portal";

$conn = mysqli_connect($server_name, $user_name, $password, $db_name) or mysqli_connect_error();

$hostname = "http://localhost/mainphp/job-portal";

if(!$conn){
    echo "Connection Unsuccessful...";
}

?>