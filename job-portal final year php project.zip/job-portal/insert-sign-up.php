<?php

include 'db_config.php';

if (isset($_POST['submit'])) {


    $first_name = mysqli_real_escape_string($conn, $_POST['fname']);
    $last_name = mysqli_real_escape_string($conn, $_POST['lname']);
    $user_name = mysqli_real_escape_string($conn, $_POST['username']);
    $email_id = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $cpassword = mysqli_real_escape_string($conn, $_POST['confirm-password']);
    $d_birth = mysqli_real_escape_string($conn, $_POST['dob']);    
    $phone = mysqli_real_escape_string($conn, $_POST['number']);

    // password encryption
    $pass = password_hash($password, PASSWORD_DEFAULT);
    $cpass = password_hash($cpassword, PASSWORD_DEFAULT);

    $email_query = "select * from job_seeker where email = '{$email_id}'";

    $store_query = mysqli_query($conn, $email_query) or die("Query Failesd !!");

    $email_count = mysqli_num_rows($store_query);

    if($email_count){

        echo "Email Already Exist...";
    }else{

        if($password === $cpassword){

            $sql = "insert into job_seeker (first_name, last_name, username, email, password, cpassword, date_of_birth, phone) 
                values('{$first_name}', '{$last_name}', '{$user_name}', '{$email_id}', 
               '{$pass}', '{$cpass}', '{$d_birth}', '{$phone}')";

            $result = mysqli_query($conn, $sql) or die("Query Failed.");

            if ($result) {
                header("location: {$hostname}/sign-in.php");
            } else {
                echo '<script>alert("Record Not Successfully Inserted. Please Try Again !!")</script>';
            }
        }else{

            echo "Password Not Matching !!";
        }

    }
}

mysqli_close($conn);

?>