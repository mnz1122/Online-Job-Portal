<?php

include 'db_config.php';

if(isset($_POST['send'])){

    $user_id = mysqli_real_escape_string($conn, $_POST['user-id']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    if($username == ""){
        echo '<script>alert("Please Enter The username !!!")</script>';
        return false;
    }
    $useremail = mysqli_real_escape_string($conn, $_POST['useremail']);
    if($useremail == ""){
        echo '<script>alert("Please Enter The useremail !!!")</script>';
        return false;
    }
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    if($subject == ""){
        echo '<script>alert("Please Enter The subject !!!")</script>';
        return false;
    }
    $message = mysqli_real_escape_string($conn, $_POST['usermessage']);
    if($message == ""){
        echo '<script>alert("Please Enter The message !!!")</script>';
        return false;
    }

    $ins_query = "insert into contact (contact_id, contact_username, contact_useremail, contact_subject, contact_message)  
                values ('{$user_id}', '{$username}', '{$useremail}', '{$subject}', '{$message}')";
    
    $result = mysqli_query($conn, $ins_query) or die("Your Connection is Unsuccessfull !!");
    
    if($result){

        header("location: {$hostname}/contact.php");
    }else{

        echo "<script>alert('Your Contact Information Not Inserted. Please Try Again !!')</script>";
    }

}

?>