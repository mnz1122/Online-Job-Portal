<?php
session_start();
if (isset($_SESSION['email'])) {
  header("location: {$hostname}/index.php");
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Sign In Form</title>
  <!-- External Css -->
  <link rel="stylesheet" href="css/style1.css">
  <!-- font awesome -->
  <link rel="stylesheet" href="css/all.css">
</head>

<body>
  <div class="container">
    <!-- Form Start -->
    <form method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
      <h1>Job Seeker Sign In</h1>

      <label for="email">Email</label>
      <input type="email" name="jobseeker-email" id="email" placeholder="Enter Your Email">

      <label for="password">Password</label>
      <input type="password" name="jobseeker-password" id="password" placeholder="Enter Your Password">

      <!-- <input type="checkbox" name="remember" id="remember"> -->

      <label for="remember">Remember me</label>
      <input type="submit" name="submit" value="Sign In"> <br>

      <!-- <div class="forgot-password">
        <a href="#">Forgot password?</a>
      </div> -->

      <div class="signup-link">
        <b>Create an Account?</b> <a href="signup.php"><b>Sign Up</b></a>
      </div>
    </form>
    <!-- Form End -->
  </div>
</body>

</html>

<!-- php block -->
<?php

include 'db_config.php';

if (isset($_POST['submit'])) {

  $email = $_POST['jobseeker-email'];
  
  $password = $_POST['jobseeker-password'];

  $email_search = "select * from job_seeker where email = '{$email}'";

  $email_store = mysqli_query($conn, $email_search) or die("Query Failed !!");

  $email_count = mysqli_num_rows($email_store);

  if ($email_count > 0) {

    $row = mysqli_fetch_assoc($email_store);

    $db_password = $row['password'];

    $decode_pass = password_verify($password, $db_password);

      if ($decode_pass) {

        $_SESSION['email'] = $row['email'];

        header("location: {$hostname}/index.php");
      } else {
        echo "<script>alert('Your Password is Incorrect !!')</script>";
      }
  } else {
    echo "<script>alert('Invalid Email !!')</script>";
  }
}

mysqli_close($conn);

?>