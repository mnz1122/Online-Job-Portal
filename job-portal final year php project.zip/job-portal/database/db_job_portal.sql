-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2023 at 07:18 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_job_portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `about_id` int(10) NOT NULL,
  `about_title` varchar(150) NOT NULL,
  `about_desc` varchar(500) NOT NULL,
  `about_image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`about_id`, `about_title`, `about_desc`, `about_image`) VALUES
(10, 'Online Job Search System', 'This is our amazing online job portal search system which is available free for every interested candidates to use this online search platform for finding the various kind of jobs having various categories to apply for it by using the application form. for the interested candidates first who need to make their own resume to full fill the qualification according to the desirable job vacancy then he make their own registration  with us to join our site for finding the jobs.', 'comp3.jpg'),
(12, 'Welcome To Online Job System', 'This is our amazing online job portal search system which is available free for every interested candidates to use this online search platform for finding the various kind of jobs having various categories to apply for it by using the application form. for the interested candidates first who need to make their own resume to full fill the qualification according to the desirable job vacancy then he make their own registration with us to join our site for finding the jobs.', 'comp3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(10) NOT NULL,
  `admin_firstname` varchar(40) NOT NULL,
  `admin_lastname` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_username` varchar(40) NOT NULL,
  `admin_password` varchar(150) NOT NULL,
  `admin_cpassword` varchar(150) NOT NULL,
  `admin_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `admin_firstname`, `admin_lastname`, `admin_email`, `admin_username`, `admin_password`, `admin_cpassword`, `admin_type`) VALUES
(30, 'Muhammad', 'Nawaz', 'nawazkhan1122@gmail.com', 'Muhammad Nawaz', '$2y$10$1dZDOYQuUTYLEqClOW2oL.dKROKKtzIqIdlUV1JDS/WUBHRA1xdU.', '$2y$10$TWPkCnmNpj6oRghYkp9rzOTrybludbsEqzKJTXoQkgHAflKbGyXVi', '1'),
(31, 'Mohsin', 'Khan', 'mohsin2233@gmail.com', 'Mohsin Khan', '$2y$10$BDql0X7K19QgApjyIBCGk.xkkvo42dtxe8c9pIb5w32vPKOZkw/n6', '$2y$10$Eu.fN2FulbVPqLFlhhh1Z.BlUqe1Y9onGN6JHEewxRNy1kxF2rJHW', '0'),
(32, 'Huzaifa', 'Yousaf', 'huzaifakhan@gmail.com', 'Huzaifa Yousaf', '$2y$10$oT/e2pgxA48vyjGL4b9hPu3xe4uIXsjKcGwZmkCdHhdBPwpHQpose', '$2y$10$uNh4Gez7WRwCED46Kb/54ebTZXfdlox5hJQjb0IamQ9MzLN.hTR6S', '0'),
(34, 'Mian ', 'Usman', 'usmankhan@gmail.com', 'Mian Usman', '$2y$10$IaqQkibYS2GDvvscozlTfeE8X9bc/ElAYjTRLLBWkUvYTXgBVCg8a', '$2y$10$oKXNOZOJHc/0MNvYlYRxku8lFxS9IcaSLB.4Ottv27.6IHwne6C4K', '0');

-- --------------------------------------------------------

--
-- Table structure for table `all_jobs`
--

CREATE TABLE `all_jobs` (
  `job_id` int(20) NOT NULL,
  `job_title` varchar(50) NOT NULL,
  `job_desc` varchar(200) NOT NULL,
  `customer_email` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `category` varchar(100) NOT NULL,
  `keyword` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_jobs`
--

INSERT INTO `all_jobs` (`job_id`, `job_title`, `job_desc`, `customer_email`, `city`, `state`, `country`, `category`, `keyword`) VALUES
(21, 'Daraz seller', 'Daraz seller course free for all the interesting students to get the chance of getting the vacancy.', 'nawazkhan1122@gmail.com', 'pakistan', 'pakistan', 'peshawer', 'Online Business', 'daraz'),
(22, 'Machine Learning', 'The machine learning is now days highly usefull sub field of the AI. In ml we train the model for the problem domain.', 'mohsin2233@gmail.com', 'turkey', 'turkey', 'istanbol', 'Machine Learning', 'machine learning'),
(25, 'Computer Operator', 'Fresh computer operator job vacancies announced here for the desireable candidates who can the chance to get it as quick as possible.', 'nawazkhan1122@gmail.com', 'pakistan', 'pakistan', 'peshawer', 'Computer', 'computer'),
(29, 'PHP Development', 'This is php development job vacancies for the php expert developer to get the maximum chance of getting more and more experiences.', 'mohsin2233@gmail.com', 'dubai', 'UAE', 'dubai', 'PHP', 'php'),
(30, 'Computer Vision', 'This the computer vision job vacancies for the computer vision expert to gain the uppertunity to get the high qualified training in computer vision field.', 'huzaifakhan@gmail.com', 'pakistan', 'pakistan', 'peshawer', 'Machine Learning', 'machine learning'),
(31, 'Traffic Monitoring System', 'This is the computer vision related job the job is traffic monitoring system which is used by the motor ways authority for tracking the vehicle speed and count it.', 'nawazkhan1122@gmail.com', 'pakistan', 'pakistan', 'peshawer', 'Computer', 'computer'),
(38, 'Amazon FBA Whole Sale', 'This the amazon FBA whole sale business for the interested people who want to start his own business on amazon as an FBA whole seller.', 'nawazkhan1122@gmail.com', 'turkey', 'turkey', 'istanbol', 'Online Business', 'whole sale'),
(39, 'Speech Recognition', 'This the speech recognition job for the people who have the expert level knowledge in machine learning know the categories. The speech recognition is the AI base project which can be access by the non', 'nawazkhan1122@gmail.com', 'china', 'china', 'shangai', 'Machine Learning', 'machine learning'),
(40, 'Facial Recognition', 'This is facial recognition category of the machine learning which is the subset of the Artificial intellegence.the job of facial recognition is ready to apply.', 'mohsin2233@gmail.com', 'turkey', 'turkey', 'istanbol', 'Machine Learning', 'machine learning'),
(41, 'Affiliate Marketing', 'This is the affiliate marketing fresh jobs in california the state of america need an expert and skillfull affiliate marketer having the ability to gain the trust of the customers toward our products.', 'nawazkhan1122@gmail.com', 'california', 'america', 'new york', 'Online Business', 'affiliate marketer');

-- --------------------------------------------------------

--
-- Table structure for table `apply_job`
--

CREATE TABLE `apply_job` (
  `apply_id` int(10) NOT NULL,
  `apply_firstname` varchar(50) NOT NULL,
  `apply_lastname` varchar(50) NOT NULL,
  `apply_seekername` varchar(40) NOT NULL,
  `apply_dob` varchar(40) NOT NULL,
  `job_id` int(10) NOT NULL,
  `file` varchar(100) NOT NULL,
  `Mobile` varchar(15) NOT NULL,
  `apply_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `apply_job`
--

INSERT INTO `apply_job` (`apply_id`, `apply_firstname`, `apply_lastname`, `apply_seekername`, `apply_dob`, `job_id`, `file`, `Mobile`, `apply_date`) VALUES
(36, 'MNawaz', 'Khan', 'nawaz1122@gmail.com', '2000-06-04', 22, 'comp2.jpg', '03125647688', '2023-06-01'),
(37, 'Javed', 'Khan', 'javed4422@gmail.com', '1996-06-04', 25, 'man made.jpg', '03245676567', '2023-06-03'),
(39, 'Mohmand', 'Nawaz Mohmand', 'nawazahmadjan810@gmail.com', '2001-05-04', 30, 'comp1.jpg', '03169841897', '2023-06-07'),
(40, 'Javed', 'Mohmand', 'javed4422@gmail.com', '1997-05-04', 21, 'javed.jpg.jpg', '03457528554', '2023-06-08'),
(42, 'Hizar', 'Hayat', 'hizarhayat@gmail.com', '2001-05-04', 21, 'person_4.jpg', '03245679812', '2023-06-15'),
(43, 'Hizar', 'Khan', 'hizarhayat@gmail.com', '2000-03-04', 25, 'comp1.jpg', '03169841446', '2023-06-20'),
(44, 'Hizar', 'Ali', 'hizarhayat@gmail.com', '2001-06-05', 29, 'man made.jpg', '03245677654', '2023-06-21'),
(45, 'Ahmad', 'Nawaz', 'nawaz1122@gmail.com', '2002-05-03', 30, 'sea.jpg', '03245677667', '2023-06-22');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `comp_id` int(20) NOT NULL,
  `comp_name` varchar(50) NOT NULL,
  `comp_desc` varchar(250) NOT NULL,
  `comp_admin` varchar(160) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`comp_id`, `comp_name`, `comp_desc`, `comp_admin`) VALUES
(26, 'Mysql Database', 'This is the mysql database company which is most popular in the world like oracle , sql, sqlserver etc', 'huzaifakhan@gmail.com'),
(27, 'Facebook', 'A Facebook is the most popular social media networking website in the world. It is usefull plateform for any users in the world.', 'mohsin2233@gmail.com'),
(30, 'Twitter', 'This is the twitter company it is a social media platform like facebook, instagram etc which is most popular in the world use by professional peoples.', 'usmankhan@gmail.com'),
(31, 'computer Programming', 'This is the computer programming company hiring the interesting expert computer programmer in any programming languages.', 'usmankhan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(10) NOT NULL,
  `contact_username` varchar(100) NOT NULL,
  `contact_useremail` varchar(100) NOT NULL,
  `contact_subject` varchar(200) NOT NULL,
  `contact_message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `contact_username`, `contact_useremail`, `contact_subject`, `contact_message`) VALUES
(1, 'Muhammad Nawaz', 'nawaz1122@gmail.com', 'Job Seeker', 'HELLO i am a job seeker searching for the desired jobs to apply.'),
(3, 'mohsinkhan', 'mohsin2233@gmail.com', 'Job Seeker', 'hey i am mohsin khan i visit your platform for the first to access the job opurtunities as well as possible but i have no idea to the find the job and apply for it.'),
(4, 'Waqas khan', 'waqaskhan@gmail.com', 'Job Seeker', 'hey i am waqas khan i visit your platform for the first time to access the job opurtunities as well as possible but i have no idea to the find the job and apply for it.please provide guidence for me.');

-- --------------------------------------------------------

--
-- Table structure for table `job_category`
--

CREATE TABLE `job_category` (
  `cid` int(20) NOT NULL,
  `category_job` varchar(100) NOT NULL,
  `cat_desc` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job_category`
--

INSERT INTO `job_category` (`cid`, `category_job`, `cat_desc`) VALUES
(1, 'Python', 'Full time job available for python apply quickly as possible also you can get the road map from chat gpt quickly.'),
(3, 'PHP', 'PHP fresh jobs for fresher get the oppertunity as possible as quickly to get more and more benefit.'),
(4, 'Machine Learning', 'A machine learning is the sub part/sub set of the artificial intellegence now a days it is most popular in the world.'),
(10, 'Online Business', 'This is the business category here all type of business will added here for the business people. '),
(11, 'Computer', 'This the computer category for computer related jobs here the candidates can find many computer related jobs.'),
(12, 'Education', 'This is the education category here different education fields can be adding for the interested people who have experiences in different field subject.');

-- --------------------------------------------------------

--
-- Table structure for table `job_seeker`
--

CREATE TABLE `job_seeker` (
  `sid` int(10) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(150) NOT NULL,
  `cpassword` varchar(150) NOT NULL,
  `date_of_birth` varchar(30) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job_seeker`
--

INSERT INTO `job_seeker` (`sid`, `first_name`, `last_name`, `username`, `email`, `password`, `cpassword`, `date_of_birth`, `phone`) VALUES
(7, 'Muhammad Nawaz', 'Khan Mohmand', 'nawazkhan', 'nawaz1122@gmail.com', '$2y$10$qxT/pdbtpyqCJrDgxNUISOAR5AkuLU4mBmzCDerDmWPgQ9ZMoy5ka', '$2y$10$vKdZYF9y5SNWWqjFuqbIteHUjdDvkCsU33C6MUYY2Bbv/4hTcZfNS', '2002-03-02', '03457528587'),
(8, 'Javed', 'Khan', 'javedkhan', 'javed4422@gmail.com', '$2y$10$9R1yy2/kEv4fTLxWJPnMDOAmmYUdIt6ewJLGhWbiZxk/8nTUS/wIm', '$2y$10$4Wnfj6Z7jcpeTJD3xtsiPOly..FKeSWCCWe2NPp5LtD3lprntwZY2', '1996-07-05', '03245679889'),
(9, 'Mohmand', 'Nawaz', 'Nawaz Mohmand', 'nawazahmadjan810@gmail.com', '$2y$10$GSWErUTF4oY6bzVi0J46Du4qZZYbJcDJd6Qbg30l8ldmyhJds63KC', '$2y$10$qQY56RmnrPaYBCJ0w8Do6OnSw.0logcIsgmejDSGV2e7Z7R0kvKjy', '2001-05-04', '03169841446'),
(10, 'Waqas', 'Jan', 'waqaskhan', 'waqaskhan@gmail.com', '$2y$10$9Lidg3EkWPpFAGxiDdQK6u7EF9oBsjNrOo55JuoidXo2sdSneXNtC', '$2y$10$DlFp0KK7RlWGEUjDHQCEw.S3wvKQRvLFbWP4S2P5cNDPBZDg9Ru2y', '2000-03-04', '03457526743'),
(11, 'Hizar', 'Hayat', 'hizarhayat', 'hizarhayat@gmail.com', '$2y$10$VwBmJthijatrNNVyPwQPIeXj13zwzJ8KS4NMvn0vqTOfUMFomTfiO', '$2y$10$6b0ZGWNzAPI/Ih4iNQZJce7MLMVPC8J8qczPNUJrTAa65ZdPoN7ge', '2001-04-02', '03245677654'),
(12, 'Akhter', 'ali', 'Akhter Ali', 'akhterali1212@gmail.com', '$2y$10$b0tMUzQLrABCL8cphry/1.QRrS.H.7doiwFSb0Z.vN1gwjJgVjXgS', '$2y$10$MmtKOylyDaFiilbWukWFTu0lufcx0pUDT18L2fEd.VCQJUZVReNSy', '2000-07-27', '033378796456');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `profile_id` int(5) NOT NULL,
  `profile_name` varchar(30) NOT NULL,
  `profile_email` varchar(25) NOT NULL,
  `profile_useremail` varchar(50) NOT NULL,
  `profile_phone` varchar(15) NOT NULL,
  `profile_dob` varchar(20) NOT NULL,
  `profile_address` varchar(100) NOT NULL,
  `profile_img` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`profile_id`, `profile_name`, `profile_email`, `profile_useremail`, `profile_phone`, `profile_dob`, `profile_address`, `profile_img`) VALUES
(3, 'Nawaz Khan', 'nawaz1122@gmail.com', 'nawaz1122@gmail.com', '03457545399', '1998-06-04', 'Post Office Sardheri Charsadda', 'IMG-20210606-WA0006.jpg'),
(6, 'Javed Khan', 'javed4422@gmail.com', 'javed4422@gmail.com', '03245679889', '1996-07-05', 'Charsadda Sardheri', 'nawaz3.jpg'),
(7, 'Nawaz Khan', 'nawaz1122@gmail.com', 'nawazkhan1122@gmail.com', '03457545399', '1998-06-04', 'Post Office Sardheri District Charsadda', 'mohsin2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `type_admin`
--

CREATE TABLE `type_admin` (
  `aid` int(10) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `type_admin`
--

INSERT INTO `type_admin` (`aid`, `type`) VALUES
(1, 'Admin'),
(0, 'Normal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`about_id`);

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `all_jobs`
--
ALTER TABLE `all_jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `apply_job`
--
ALTER TABLE `apply_job`
  ADD PRIMARY KEY (`apply_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `job_category`
--
ALTER TABLE `job_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `job_seeker`
--
ALTER TABLE `job_seeker`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`profile_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `about_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `all_jobs`
--
ALTER TABLE `all_jobs`
  MODIFY `job_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `apply_job`
--
ALTER TABLE `apply_job`
  MODIFY `apply_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `comp_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `job_category`
--
ALTER TABLE `job_category`
  MODIFY `cid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `job_seeker`
--
ALTER TABLE `job_seeker`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `profile_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
