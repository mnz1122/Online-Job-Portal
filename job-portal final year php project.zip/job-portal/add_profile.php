<?php

session_start();
$user_email = $_SESSION['email'];

include 'db_config.php';

$name = $_POST['name'];
$email = $_POST['email'];
$mobile = $_POST['phone'];
$dob = $_POST['dob'];
$address = $_POST['address'];
$file_img = $_FILES['img']['name'];
$tmp_file = $_FILES['img']['tmp_name'];

$sql = "select * from profile where profile_useremail = '{$user_email}'";
$my_query = mysqli_query($conn, $sql) or die("Query Of Select Failed !!");
$check = mysqli_num_rows($my_query);
if(!empty($check)){

    move_uploaded_file($tmp_file, 'profile_img/'.$file_img);
    $update_query = "update profile set profile_name = '{$name}', profile_email = '{$email}', profile_phone = '{$mobile}', 
                profile_dob = '{$dob}', profile_address = '{$address}', profile_img = '{$file_img}' where profile_useremail = '{$user_email}'";

    $result_update = mysqli_query($conn, $update_query) or die("Quer Of Update Unsuccessfull !!");

    if($result_update){
        // echo "<h3>Job Seeker Profile Updated Successfully !!</h3>";
        header("location:{$hostname}/my_profile.php");
    }else{
        echo "<h3>Job Seeker Profile Does Not Updated Successfully. Please Try Again !!</h3>";
    }
}else{

// this query is for insert when job seeker enter first time into site
move_uploaded_file($tmp_file, 'profile_img/'.$file_img);
$query = "insert into profile (profile_name, profile_email, profile_useremail, profile_phone, profile_dob, profile_address, profile_img) 
         values ('{$name}', '{$email}', '{$user_email}', '{$mobile}', '{$dob}', '{$address}', '{$file_img}')";

$output = mysqli_query($conn, $query) or die("Query Of Insert Unsuccessful !!");

if($output){
    // echo "<h3>Job Seeker Profile Added Successfully !!</h3>";
    header("location:{$hostname}/my_profile.php");
}else{
    echo "<h3>Profile Not Updated Please Try Again !!</h3>";
}

}

mysqli_close($conn);
