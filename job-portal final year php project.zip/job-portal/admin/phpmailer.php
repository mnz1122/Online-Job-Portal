<!-- <?php  
// session_start();
// if($_SESSION['admin_type'] == '0'){
//     header("location: {$hostname}/admin/job-create.php");
// }
?> -->
<!DOCTYPE html>
<html>

<head>
    <title></title>
    <!-- bootstrap css link -->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!-- jquery link -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <!-- bootstrap js link -->
    <link rel="stylesheet" href="js/bootstrap.bundle.min.js" />
</head>

<body>
    <?php
    //Import PHPMailer classes into the global namespace
    //These must be at the top of your script, not inside a function
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    //Load Composer's autoloader
    require 'email/vendor/autoload.php';

    $to = $_POST['to'];
    $from = $_POST['from'];
    $body = $_POST['body'];
    $id = $_POST['id'];

    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {
        //Server settings
        $mail->SMTPDebug = 1;                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = $from;                     //SMTP username
        $mail->Password   = 'huzaifa';                               //SMTP password
        $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
        $mail->Port       = 25;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`                                   //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom($to, 'host programming');
        $mail->addAddress($from, 'Joe User');     //Add a recipient
        // $mail->addAddress('ellen@example.com');               //Name is optional
        // $mail->addReplyTo('info@example.com', 'Information');
        // $mail->addCC('cc@example.com');
        // $mail->addBCC('bcc@example.com');

        //Attachments
        // $mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
        // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

        //Content
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Here is the subject';
        $mail->Body    = $body;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        $mail->send();
        echo 'Message has been sent';
        include 'config.php';
        // delete record from databse when email is sending to applicant
        $query = "delete from apply_job where apply_id = {$id}";
        $store = mysqli_query($conn, $query) or die("Query Failed !!");

        echo "<script>
                window.setTimeout(function(){
                    window.location.href = '{$hostname}/admin/apply_job.php'; 
                }, 5000);
            </script>";
            

    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }

    ?>
    <br><br><a href="apply_job.php" class="btn btn-success p-3 ml-5">Back</a>
</body>

</html>