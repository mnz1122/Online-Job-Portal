<?php include "include/header.php";
//authentication
// if ($_SESSION['admin_type'] == '0') {
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">Contact View</h1><br>
            </div>
            <!-- php code -->
            <?php

            include 'config.php';

            $con_id = $_GET['con-view'];
            $sql = "select * from contact where contact_id = {$con_id}";

            $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

            if (mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_assoc($result)) {
                    // $cont_isd = $row['contact_id'];
                    $contact_name = $row['contact_username'];
                    $contact_email = $row['contact_useremail'];
                    $contact_subject = $row['contact_subject'];
                    $contact_message = $row['contact_message'];
            ?>
                    <fieldset style="border: 2px solid grey; width:75%; margin: 50px auto 50px auto; padding:25px; border-radius: 10px;">
                        <!-- <legend>Job Seeker Details</legend> -->
                        <!-- <tr>
                                <td><?php echo $contact_id; ?></td>
                            </tr> -->
                        <tr>
                            <label for="contact name"><b>UserName :</b></label>
                            <td><?php echo $contact_name; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="useremail"><b>UserEmail :</b></label>
                            <td><?php echo $contact_email; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="subject"><b>Subject :</b></label>
                            <td><?php echo $contact_subject; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="message"><b>Message :</b></label>
                            <td><?php echo $contact_message; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <td>
                                <a href="contact-send.php?send-conid=<?php echo $con_id; ?>" class="btn btn-success text-white p-2">Accept</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="contact-reject.php?rej-conid=<?php echo $con_id; ?>" class="btn btn-danger text-white p-2">Reject</a>
                            </td>
                        </tr>
                    </fieldset>
            <?php
                }
            }

            ?>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>