<?php

include 'config.php';

$delete = $_GET['job-del'];

$cat_id = $_GET['cat-id'];

$sql = "delete from all_jobs where job_id = {$delete};";

$sql .= "update job_category set job = job - 1 where cid = {$cat_id}";

$result = mysqli_multi_query($conn, $sql) or die("Query Failed !!");

if($result){
    header("location: {$hostname}/admin/job-create.php");
}else{
    echo "<p style=margin:auto; color:red; text-align:center;'>Can't Delete Recod. Please try again !!</p>";
}

mysqli_close($conn);

?>