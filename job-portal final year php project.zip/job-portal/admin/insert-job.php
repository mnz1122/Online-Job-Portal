<?php 

// job add
include 'config.php';

// form validation
$title = mysqli_real_escape_string($conn, $_POST['job_title']);

$description = mysqli_real_escape_string($conn, $_POST['job_desc']);

// $email = mysqli_real_escape_string($conn, $_POST['email']);

$keyword = mysqli_real_escape_string($conn, $_POST['keyword']);

$country = mysqli_real_escape_string($conn, $_POST['add-country']);
if($country == ""){
    echo '<script>alert("Please Enter The country !!!")</script>';
    return false;
}

$state = mysqli_real_escape_string($conn, $_POST['add-state']);
if($state == ""){
    echo '<script>alert("Please Enter The state !!!")</script>';
    return false;
}

$city = mysqli_real_escape_string($conn, $_POST['add-city']);
if($city == ""){
    echo '<script>alert("Please Enter The city !!!")</script>';
    return false;
}

$category = mysqli_real_escape_string($conn, $_POST['add-category']);

session_start();
$customer_email = mysqli_real_escape_string($conn, $_SESSION['email']);

$sql = "insert into all_jobs (job_title, job_desc, customer_email, city, state, country, category, keyword) 
        values ('{$title}', '{$description}', '{$customer_email}', '{$city}', '{$state}', '{$country}', '{$category}', '{$keyword}');";
$sql .= "update job_category set job = job + 1 where cid = {$category}";        

$result = mysqli_multi_query($conn, $sql) or die("Query Failed !!");

if($result){
    header("location: {$hostname}/admin/job-create.php");
}else{
    echo "<div class='alert alert-danger'>Record Not Added Please Try again !!</div>";
}

?>