<?php

include 'config.php';

session_start();

session_unset();

session_destroy();

$sql = "select * from admin_login where admin_email = '{$_SESSION['email']}' and admin_type = '1'";

$result = mysqli_query($conn, $sql) or die("Query Failed. ");

if($result){

    header("Location: {$hostname}/admin/login.php");
    
}else{

    header("location: {$hostname}/");
}

mysqli_close($conn);

?>