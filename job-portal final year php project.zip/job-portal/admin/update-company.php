<?php include "include/header.php"; ?>
<div id="admin-content">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="admin-heading"> Update Company</h1>
      </div>
      <div class="col-md-offset-3 col-md-6">
        <?php

        include 'config.php';

        $edit_id = $_GET['comp-edt']; 

        $sql = "select * from company where comp_id = {$edit_id}";

        $result = mysqli_query($conn, $sql) or die("Query Failed!!");

        if (mysqli_num_rows($result) > 0) {

          while ($row = mysqli_fetch_assoc($result)) {

            $comp_id = $row['comp_id'];
            $comp_name = $row['comp_name'];
            $description = $row['comp_desc'];

        ?>
            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST">
              <div class="form-group">
                <input type="hidden" name="comp-id" class="form-control" value="<?php echo $comp_id; ?>" placeholder="">
              </div>
              <div class="form-group">
                <label>Company Name</label>
                <input type="text" name="comp-name" class="form-control" value="<?php echo $comp_name; ?>" placeholder="" required>
              </div>
              <div class="form-group">
                <label for="description"> Description</label>
                <textarea name="comp-desc" class="form-control" rows="5" required><?php echo $description; ?></textarea>
              </div>
              <div class="form-group">
                <label for="comp admin">Update Company Admin</label>
                <select name="comp-admin" id="comp-admin" class="form-control">
                  <?php

                  include 'config.php';

                  $sql1 = "select * from admin_login where admin_type = '0'";

                  $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");

                  if (mysqli_num_rows($result1) > 0) {

                    while ($row1 = mysqli_fetch_assoc($result1)) {
                      if($row1['admin_email'] == $row['comp_admin']){
                        $selected = "selected";
                      }else{
                        $selected = "";
                      }

                      echo "<option {$selected} value='{$row1['admin_id']}'>{$row1['admin_email']}</option>";
                    }
                  }

                  ?>
                </select>
              </div>
              <input type="submit" name="update" class="btn btn-success btn-block" value="Update" required />
            </form>
        <?php

          }
        }

        ?>
      </div>
    </div>
  </div>
</div>
<?php include "include/footer.php"; ?>

<!-- php block -->
<?php

// include 'config.php';

if (isset($_POST['update'])) {

  $company = mysqli_real_escape_string($conn, $_POST['comp-name']);

  $company_desc = mysqli_real_escape_string($conn, $_POST['comp-desc']);

  $comp_admin = mysqli_real_escape_string($conn, $_POST['comp-admin']);

  $update_query = "update company set comp_name = '{$company}', comp_desc = '{$company_desc}', 
                  comp_admin = '{$comp_admin}' where comp_id = {$edit_id}";

  $store_update = mysqli_query($conn, $update_query) or die("Query Failed !!");

  if ($store_update) {
    echo "<script>alert('Record Updated !!!')</script>";
    // header("location: {$hostname}/admin/company.php");
  } else {

    echo "<script>alert('Record Can't Updated Please try again !!!')</script>";
  }
}

mysqli_close($conn);

?>