<?php

//authentication
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}

include 'config.php';

$del_id = $_GET['cat-del'];

$sql = "delete from job_category where cid = {$del_id}";

$result = mysqli_query($conn, $sql) or die("Query Failed : Delete.");

if($result){

    header("location: {$hostname}/admin/category.php");
}else{

    echo '<p style="color:red; margin:10px 0; text-align:center;">No Record Deleted, Please try again !!</p>';
}

?>