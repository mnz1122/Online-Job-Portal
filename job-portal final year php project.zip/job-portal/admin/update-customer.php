<?php include "include/header.php"; 
//authentication
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Modify Customer Details</h1>
            </div>
            <div class="col-md-offset-4 col-md-4">

                <?php

                include 'config.php';

                $edit_id = $_GET['cust-edt'];

                $sql = "select * from admin_login where admin_id = {$edit_id}";

                $result = mysqli_query($conn, $sql) or die("Query Failed!!");

                if (mysqli_num_rows($result) > 0) {

                    while ($row = mysqli_fetch_assoc($result)) {

                        $customer_id = $row['admin_id'];
                        $admin_fname = $row['admin_firstname'];
                        $admin_lname = $row['admin_lastname'];
                        $admin_username = $row['admin_username'];
                        $admin_email = $row['admin_email'];
                        $admin_role = $row['admin_type'];

                ?>

                        <!-- Form Start -->
                        <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" class="mt-5">
                            <div class="form-group">
                                <input type="hidden" name="admin-id" class="form-control" value="<?php echo $customer_id; ?>" placeholder="">
                            </div>
                            <div class="form-group">
                                <label>First Name</label>
                                <input type="text" name="f_name" class="form-control" value="<?php echo $admin_fname; ?>" placeholder="" required>
                            </div>
                            <div class="form-group">
                                <label>Last Name</label>
                                <input type="text" name="l_name" class="form-control" value="<?php echo $admin_lname; ?>" placeholder="" required>
                            </div>
                            <div class="form-group">
                                <label>User Name</label>
                                <input type="text" name="username" class="form-control" value="<?php echo $admin_username; ?>" placeholder="" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" value="<?php echo $admin_email; ?>" placeholder="" required>
                            </div>
                            <div class="form-group">
                                <label>Admin Type</label>
                                <select class="form-control" name="role" value="">
                                    <!-- <option value="0">Normal</option>
                                    <option value="1">Admin</option> -->
                                    <?php
                                    if ($row['admin_type'] == 1) {
                                        echo '<option value="1" selected>Admin</option>
                                               <option value="0">Normal</option>';
                                    } else {
                                        echo '<option value="0" selected>Normal</option>
                                              <option value="1">Admin</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <input type="submit" name="submit" class="btn btn-primary btn-block" value="Update" required />
                        </form>
                        <!-- /Form -->

                <?php
                    }
                }
                ?>

            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>

<!-- php block -->
<?php

include 'config.php';

if (isset($_POST['submit'])) {

    // $edit_id = $_GET['edit'];

    $first_name = mysqli_real_escape_string($conn, $_POST['f_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['l_name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    // $password = mysqli_real_escape_string($conn, md5($_POST['password']));
    $admin_type = mysqli_real_escape_string($conn, $_POST['role']);

    $sql1 = "update admin_login set admin_firstname = '{$first_name}', admin_lastname = '{$last_name}', 
            admin_username = '{$username}', admin_email = '{$email}', admin_type = {$admin_type}  
            where admin_id = {$edit_id}";

    $result1 = mysqli_query($conn, $sql1) or die("Query Failed!!!");

    if ($result1) {

        echo "<script style='color:green; text-align:center;'>alert('Record Successfully Updated !!!')</script>";
        // header("location: {$hostname}/admin/customer.php");
    } else {

        echo "<script>alert('Record Can't Updated Please try again !!!')</script>";
    }
}

mysqli_close($conn);

?>