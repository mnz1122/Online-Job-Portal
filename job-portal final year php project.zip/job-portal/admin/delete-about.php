<?php

session_start();
//authentication
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}

include 'config.php';

$catch_id = $_GET['abt-del'];

$sql = "delete from about where about_id = {$catch_id}";

$result = mysqli_query($conn, $sql) or die("Query Failed : Delete");

if($result){

    header("location: {$hostname}/admin/about.php");
}else{

    echo "<p style='color:red; text-align:center; margin:10px 0;'>Can't Delete Record.</p>";
}

?>