<?php include "include/header.php";
$page='home'; 
// if ($_SESSION['admin_type'] == '0') {
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="card">Total Jobs</div>
    <div class="card1">Total Category</div>
    <div class="card2">Total Candidates</div>
    <div class="card3">Total Employer</div>
</div>
<?php include "include/footer.php"; ?>