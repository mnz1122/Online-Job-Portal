<?php

$conn = mysqli_connect("localhost", "root", "", "db_job_portal");

$hostname = "http://localhost/mainphp/job-portal";

if(!$conn){

    echo "<script>alert('Connection UnSuccessfull !!')</script>";
}

?>