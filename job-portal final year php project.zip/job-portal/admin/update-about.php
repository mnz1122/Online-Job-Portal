<?php include "include/header.php"; 
//authentication
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Modify About Details</h1>
            </div>
            <div class="col-md-offset-4 col-md-4">

                <?php

                include 'config.php';

                $edit_id = $_GET['abt-edt'];

                $sql = "select * from about where about_id = {$edit_id}";

                $result = mysqli_query($conn, $sql) or die("Query Failed!!");

                if (mysqli_num_rows($result) > 0) {

                    while ($row = mysqli_fetch_assoc($result)) {

                        $about_id = $row['about_id'];
                        $about_title = $row['about_title'];
                        $about_desc = $row['about_desc'];
                        $about_image = $row['about_image'];

                ?>

                        <!-- Form Start -->
                        <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" class="mt-5">
                            <div class="form-group">
                                <input type="hidden" name="about-id" class="form-control" value="<?php echo $about_id; ?>" placeholder="">
                            </div>
                            <div class="form-group">
                                <label>About Title</label>
                                <input type="text" name="about-title" class="form-control" value="<?php echo $about_title; ?>" placeholder="" required>
                            </div>
                            <div class="form-group">
                                <label>About Description</label>
                               <textarea name="about-desc" id="about-desc" class="form-control" cols="20" rows="10"><?php echo $about_desc; ?></textarea>
                            </div>
                            <div class="form-group">
                                <label>Image</label>
                                <input type="file" name="fileToUpload" class="form-control" value="<?php echo $about_image; ?>" placeholder="" required>
                            </div>
                            <input type="submit" name="submit" class="btn btn-primary btn-block" value="Update" required />
                        </form>
                        <!-- /Form -->

                <?php
                    }
                }
                ?>

            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>

<!-- php block -->
<?php

include 'config.php';

if (isset($_POST['submit'])) {

    if(isset($_FILES['fileToUpload'])){

        $errors = array();
    
        $about_file = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['name']);
        $file_size = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['size']);
        $file_tmp = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['tmp_name']);
        $file_type = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['type']);
        $file_ext = strtolower(end(explode('.', $about_file)));
        $extension = array("jpeg", "png", "jpg", "pdf");
    
        if(in_array($file_ext, $extension) === false){
    
            $errors[] = "This extension file is not allowed.Please choose the png or jpg or pdf or jpeg...";
        }
        if($file_size > 4194304){
    
            $errors[] = "File size must be 4MB or less...";
        }
        if(empty($errors) == true){
    
            move_uploaded_file($file_tmp, "upload/".$about_file);
        }else{
            print_r($errors);
            die();
        }
    }
    

    $title = mysqli_real_escape_string($conn, $_POST['about-title']);
    $about_description = mysqli_real_escape_string($conn, $_POST['about-desc']);
    
    move_uploaded_file($tmp_file, 'files/'.$about_file);
    $sql1 = "update about set about_title = '{$title}', about_desc = '{$about_description}', 
            about_image = '{$about_file}' where about_id = {$edit_id}";

    $result1 = mysqli_query($conn, $sql1) or die("Query Failed!!!");

    if ($result1) {

        echo "<script style='color:green; text-align:center;'>alert('Record Successfully Updated !!!')</script>";
        // header("location: {$hostname}/admin/customer.php");
    } else {

        echo "<script>alert('Record Can't Updated Please try again !!!')</script>";
    }
}

mysqli_close($conn);

?>