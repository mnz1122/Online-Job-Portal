<?php include "include/header.php"; 
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="admin-heading">Add New Category</h1>
              </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- form start -->
                  <form action="insert-category.php" method="POST" style="margin:4%; padding:3%;" name="category-form" id="cat-form">
                      <div class="form-group">
                          <input type="hidden" name="cat_id" id="cat_id" class="form-control" placeholder="">
                      </div>
                      <div class="form-group">
                          <label for="Category Name">Enter Category Name</label>
                          <input type="text" name="cat_name" id="cat_name" class="form-control" placeholder="Enter Category Name">
                      </div>
                      <div class="form-group">
                          <label for="Cat Description">Enter Category Description</label>
                          <textarea name="description" id="description" class="form-control" cols="20" rows="10"></textarea>
                      </div>
                      <div class="form-group">
                          <input type="submit" name="submit" placeholdee="submit" id="submit" class="btn btn-success btn-block">
                      </div>
                  </form>
                  <!-- form end -->
              </div>
          </div>
      </div>
  </div>
<?php include "include/footer.php"; ?>
