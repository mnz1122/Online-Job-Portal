<?php include "include/header.php";
//authentication
// if ($_SESSION['admin_type'] == '0') {
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">View Applied Job</h1><br>
            </div>
            <!-- php code -->
            <?php

            include 'config.php';

            $job_id = $_GET['job-view'];
            $sql = "select job_title, apply_firstname, apply_lastname, apply_seekername, job_desc, mobile, file from 
                                apply_job left join all_jobs on apply_job.job_id = all_jobs.job_id  
                                where apply_id = {$job_id}";

            $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

            if (mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_assoc($result)) {

                    // $job = $row['job_id'];
                    $title = $row['job_title'];
                    $description = $row['job_desc'];
                    $first_name = $row['apply_firstname'];
                    $last_name = $row['apply_lastname'];
                    $seeker = $row['apply_seekername'];
                    $mobile = $row['mobile'];
                    $file = $row['file'];
            ?>
                    <fieldset style="border: 2px solid grey; width:75%; margin: 50px auto 50px auto; padding:25px; border-radius: 10px;">
                        <!-- <legend>Job Seeker Details</legend> -->
                        <!-- <tr>
                                <td><?php echo $job_id; ?></td>
                            </tr> -->
                        <tr>
                            <label for="job title"><b>Job Title :</b></label>
                            <td><?php echo $title; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="description"><b>Description :</b></label>
                            <td><?php echo $description; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="username"><b>Username :</b></label>
                            <td><?php echo $first_name; ?> <?php echo $last_name; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="job seeker email"><b>Job Seeker Email :</b></label>
                            <td><?php echo $seeker; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="mobile number"><b>Job Seeker Mobile Number :</b></label>
                            <td><?php echo $mobile; ?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <label for="resume file"><b>Resume :</b></label>
                            <td><?php echo $file;?></td>
                        </tr>
                        <br><br>
                        <tr>
                            <td>
                                <a href="send-mail.php?send-id=<?php echo $job_id; ?>" class="btn btn-success text-white p-2">Accept</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                <a href="reject-mail.php?rej-id=<?php echo $job_id; ?>" class="btn btn-danger text-white p-2">Reject</a>
                            </td>
                        </tr>
                    </fieldset>
                    <!-- <td>
                                    <div class="row">
                                          <a href="view_applied_job.php?job-view=<?php echo $job_id; ?>" class="mr-4 text-info pl-4"><i class='fas fa-eye fa-lg'></i></a> -->
                    <!-- <a href="job_delete.php?job-del=<?php echo $row['job_id']; ?>" class="text-danger"><i class='fa fa-trash'></i></a> -->
                    <!-- </div> -->
                    <!-- </td> -->
            <?php
                }
            }

            ?>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>