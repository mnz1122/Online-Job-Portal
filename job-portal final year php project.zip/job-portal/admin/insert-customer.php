<?php

//authentication
session_start();
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}

include 'config.php';

$first_name = mysqli_real_escape_string($conn, $_POST['fname']);
$last_name = mysqli_real_escape_string($conn,$_POST['lname']);
$username = mysqli_real_escape_string($conn,$_POST['user']);
$email_id = mysqli_real_escape_string($conn,$_POST['email']);
$pass = mysqli_real_escape_string($conn, $_POST['password']);
$cpass = mysqli_real_escape_string($conn, $_POST['cpassword']);
$admin_type = mysqli_real_escape_string($conn,$_POST['type']);

$enc_pass = password_hash($pass, PASSWORD_DEFAULT);
$enc_cpass = password_hash($cpass, PASSWORD_DEFAULT);

$sql = "insert into admin_login (admin_firstname, admin_lastname, admin_username, admin_email, admin_password, admin_cpassword, admin_type) 
        values ('$first_name', '$last_name', '$username', '$email_id', '$enc_pass', '$enc_cpass', '$admin_type')";

$result = mysqli_query($conn, $sql) or die("Query Unsuccesful.");

if($result){

    // echo '<div class="alert alert-success">Data has been successfully inserted.</div>';
    header("location: {$hostname}/admin/customer.php");
}else{

    echo '<div class="alert alert-danger">Some error please try again.</div>';
}

mysqli_close($conn);

?>