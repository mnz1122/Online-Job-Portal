<?php include "include/header.php"; 
$page='contact';
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">All Contacts</h1>
            </div>
            <!-- <div class="col-md-2">
                <a class="add-new" href="add-category.php">add category
                </a>
            </div> -->
            <div class="col-md-12">

            <!-- php block -->
            <?php

            include 'config.php';

            $limit = 3;

            if(isset($_GET['page'])){
                $page = $_GET['page'];
            }else{
                $page = 1;
            }

            $offset = ($page - 1) * $limit;

            ?>
                <table class="content-table">
                    <thead>
                        <th>S.No</th>
                        <th>Contact Name</th>
                        <th>Contact Email</th>
                        <th>Contact Subject</th>
                        <th>Contact Message</th>
                        <th>Action</th>
                    <tbody>
                        <!-- php code -->
                        <?php

                        include 'config.php';

                        $sql = "select * from contact order by contact_id desc limit {$offset}, {$limit}";

                        $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {
                                $con_id = $row['contact_id'];
                                $contact_name = $row['contact_username'];
                                $contact_email = $row['contact_useremail'];
                                $contact_subject = $row['contact_subject'];
                                $contact_message = $row['contact_message'];
                        ?>
                        <tr>
                            <td><?php echo $con_id; ?></td>
                            <td><?php echo $contact_name; ?></td>
                            <td><?php echo $contact_email; ?></td>
                            <td><?php echo $contact_subject; ?></td>
                            <td><?php echo $contact_message; ?></td>
                            <td>
                                <a href="contact-view-info.php?con-view=<?php echo $con_id; ?>" class="mr-4 text-info pl-4"><i class='fas fa-eye fa-lg'></i></a>
                            </td>
                        </tr>
                        <?php 
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <?php

                    $query = "select * from contact";

                    $result_query = mysqli_query($conn, $query) or die("Query Failed !!");

                    if(mysqli_num_rows($result_query)>0){

                        $total_record = mysqli_num_rows($result_query);

                        // $limit = 3;

                        $total_pages = ceil($total_record/$limit);

                        echo "<ul class='pagination admin-pagination'>";

                        if($page > 1){

                            echo '<li><a href="contact.php?page='. ($page - 1) .'">Prev</a></li>';
                        }

                        for($i = 1; $i <= $total_pages; $i++){

                            if($i == $page){
                                $active = "active";
                            }else{
                                $active = "";
                            }

                            echo '<li class='.$active.'><a href="contact.php?page='.$i.'">'.$i.'</a></li>';
                        }

                        if($page < $total_pages){

                            echo '<li><a href="contact.php?page='. ($page + 1) .'">Next</a></li>';
                        }

                        echo "</ul>";
                    }

                ?>
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>
