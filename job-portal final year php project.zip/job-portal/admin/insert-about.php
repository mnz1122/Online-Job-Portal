<?php

//authentication
session_start();
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}

include 'config.php';

if(isset($_FILES['fileToUpload'])){

    $errors = array();

    $about_file = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['name']);
    $file_size = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['size']);
    $file_tmp = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['tmp_name']);
    $file_type = mysqli_real_escape_string($conn, $_FILES['fileToUpload']['type']);
    $file_ext = strtolower(end(explode('.', $about_file)));
    $extension = array("jpeg", "png", "jpg", "pdf");

    if(in_array($file_ext, $extension) === false){

        $errors[] = "This extension file is not allowed.Please choose the png or jpg or pdf or jpeg...";
    }
    if($file_size > 4194304){

        $errors[] = "File size must be 4MB or less...";
    }
    if(empty($errors) == true){

        move_uploaded_file($file_tmp, "upload/" .$about_file);
    }else{
        print_r($errors);
        die();
    }
}

$about_title = mysqli_real_escape_string($conn, $_POST['title']);
$about_desc = mysqli_real_escape_string($conn,$_POST['desc']);

move_uploaded_file($file_tmp, 'files/'.$about_file);

$sql = "insert into about (about_title, about_desc, about_image) 
        values ('{$about_title}', '{$about_desc}', '{$about_file}')";

$result = mysqli_query($conn, $sql) or die("Query Unsuccesful.");

if($result){

    // echo '<div class="alert alert-success">Data has been successfully inserted.</div>';
    header("location: {$hostname}/admin/about.php");
}else{

    echo '<div class="alert alert-danger">Some error please try again.</div>';
}

mysqli_close($conn);

?>