<?php include "include/header.php"; 
$page='category';
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">All Categories</h1>
            </div>
            <div class="col-md-2">
                <a class="add-new" href="add-category.php">add category
                </a>
            </div>
            <div class="col-md-12">

            <!-- php block -->
            <?php

            include 'config.php';

            $limit = 3;

            if(isset($_GET['page'])){
                $page = $_GET['page'];
            }else{
                $page = 1;
            }

            $offset = ($page - 1) * $limit;

            ?>
                <table class="content-table">
                    <thead>
                        <th>S.No</th>
                        <th>Category Name</th>
                        <th>Description</th>
                        <th>job</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        <!-- <th>Action</th> -->
                    <tbody>
                        <!-- php code -->
                        <?php

                        include 'config.php';

                        $sql = "select * from job_category order by cid desc limit {$offset}, {$limit}";

                        $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {
                                $cat_id = $row['cid'];
                                $category = $row['category_job'];
                                $cat_desc = $row['cat_desc'];
                                $job = $row['job'];
                        ?>
                        <tr>
                            <td><?php echo $cat_id; ?></td>
                            <td><?php echo $category; ?></td>
                            <td><?php echo $cat_desc; ?></td>
                            <td><?php echo $job; ?></td>
                            <td>
                                <a href="update-category.php?cat-edt=<?php echo $cat_id; ?>" class="mr-4 text-info"><i class='fa fa-edit'></i></a>
                            </td>
                            <td>
                                <a href="delete-category.php?cat-del=<?php echo $cat_id; ?>" class="text-danger"><i class='fa fa-trash'></i></a>
                            </td>
                        </tr>
                        <?php 
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <?php

                    $query = "select * from job_category";

                    $result_query = mysqli_query($conn, $query) or die("Query Failed !!");

                    if(mysqli_num_rows($result_query)>0){

                        $total_record = mysqli_num_rows($result_query);

                        // $limit = 3;

                        $total_pages = ceil($total_record/$limit);

                        echo "<ul class='pagination admin-pagination'>";

                        if($page > 1){

                            echo '<li><a href="category.php?page='. ($page - 1) .'">Prev</a></li>';
                        }

                        for($i = 1; $i <= $total_pages; $i++){

                            if($i == $page){
                                $active = "active";
                            }else{
                                $active = "";
                            }

                            echo '<li class='.$active.'><a href="category.php?page='.$i.'">'.$i.'</a></li>';
                        }

                        if($page < $total_pages){

                            echo '<li><a href="category.php?page='. ($page + 1) .'">Next</a></li>';
                        }

                        echo "</ul>";
                    }

                ?>
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>
