<?php include "include/header.php";
$page = 'report';
// if ($_SESSION['admin_type'] == '0') {
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Job Report</h1>
            </div>
            <section>
                <div class="container">
                    <div class="row">
                        <!-- Form -->
                        <div class="col-md-12">
                            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" style="height:130px;">
                                <div class="form-group col-md-4">
                                    <label for="start"><b>From Start Date</b></label>
                                    <input type="date" name="start-date" class="form-control">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="end"><b>To End Date</b></label>
                                    <input type="date" name="end-date" class="form-control">
                                </div>
                                <!-- <div class="form-group col-md-3">
                                    <label for="job">Choose A Job</label>
                                    <select name="job" class="form-control">
                                        <option value="" selected> Select Job</option>
                                        <?php  
                                            $sql = "select * from all_jobs";
                                            $result = mysqli_query($conn, $sql);
                                            if(mysqli_num_rows($result)>0){
                                                while($row = mysqli_fetch_assoc($result)){
                                                    echo "<option value='{$row['job_id']}'>{$row['job_title']}</option>";
                                                }
                                            }
                                        ?>
                                    </select>
                                </div> -->
                                <div class="form-group col-md-4">
                                    <input type="submit" name="submit" value="Generate Report" class="btn btn-primary btn-block" style="margin-top:25px;">
                                </div>
                            </form>
                        </div>
                        <!--/Form -->
                        <!-- php block -->
                        <?php

                        include 'config.php';

                        if (isset($_POST['submit'])) {

                            $start_date = $_POST['start-date'];
                            $end_date = $_POST['end-date'];
                            // $job = $_POST['job'];

                            $query = "select * from apply_job left join all_jobs on apply_job.job_id = all_jobs.job_id 
                                     where apply_date between '{$start_date}' and '{$end_date}'";
                            $store_query = mysqli_query($conn, $query) or die("Query Failed...");

                            if (mysqli_num_rows($store_query) > 0) {

                                // foreach ($store_query as $value) { 
                        ?>

                                <div class="col-md-12"><br>
                                    <table class="table table-striped">
                                        <thead style="color:#fff; background:grey; border:1px solid black;">
                                            <th>S.No</th>
                                            <th>Applicant Name</th>
                                            <th>Applied Job</th>
                                            <th>Applicant Email</th>
                                            <th>Reg. Date</th>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($store_query as $value) { ?>
                                                <tr>
                                                    <td><?= $value['apply_id']; ?></td>
                                                    <td><?= $value['apply_firstname']; ?> <?= $value['apply_lastname']; ?></td>
                                                    <td><?= $value['job_title']; ?></td>
                                                    <td><?= $value['apply_seekername']; ?></td>
                                                    <td><?= $value['apply_date']; ?></td>
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>

                        <?php
                            } else {
                                echo "<b>No Data Found...</b>";
                            }
                        }
                        // } else {
                        //     
                        ?>
                        <!-- </div> -->
                        <!-- <div class="col-md-12">
                                <table class="table table-striped">
                                    <thead style="border:2px solid dark; background:grey; color:white;">
                                        <th>S.No</th>
                                        <th>Applicant Name</th>
                                        <th>Applicant Email</th>
                                        <th>Reg. Date</th>
                                    </thead>
                                    <tbody>
                                        <?php

                                        include 'config.php';

                                        $report = "select * from apply_job";
                                        $store = mysqli_query($conn, $report) or die("Query Failed...");
                                        $i = 1;
                                        if (mysqli_num_rows($store) > 0) {
                                            while ($row = mysqli_fetch_assoc($store)) {
                                                $job_id = $row['apply_id'];
                                                $f_name = $row['apply_firstname'];
                                                $l_name = $row['apply_lastname'];
                                                $email = $row['apply_seekername'];
                                                $date = $row['apply_date'];

                                        ?>
                                                <tr>
                                                    <td><?= $job_id; ?></td>
                                                    <td><?= $f_name; ?> <?= $l_name; ?></td>
                                                    <td><?= $email; ?></td>
                                                    <td><?= $date; ?></td>
                                                </tr>
                                        <?php
                                                $i++;
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div> -->
                        <!-- <?php  ?>  -->
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>
</div>
</div>
<?php include "include/footer.php"; ?>