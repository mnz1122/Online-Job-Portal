<?php include "include/header.php"; ?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Update Job</h1>
            </div>
            <div class="col-md-offset-3 col-md-6">

                <?php

                include 'config.php';
                if (isset($_GET['job-edt'])) {
                    $edit_id = $_GET['job-edt'];
                }

                $sql = "select * from all_jobs where job_id = {$edit_id}";

                $result = mysqli_query($conn, $sql) or die("Query Failed!!");

                if (mysqli_num_rows($result) > 0) {

                    while ($row = mysqli_fetch_assoc($result)) {

                        $job_id = $row['job_id'];
                        $title = $row['job_title'];
                        $description = $row['job_desc'];
                        $keyword = $row['keyword'];
                        $country = $row['country'];
                        $state = $row['state'];
                        $city = $row['city'];
                        $category = $row['category'];

                ?>

                        <!-- Form for show edit-->
                        <form action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" enctype="multipart/form-data" autocomplete="off">
                            <div class="form-group">
                                <input type="hidden" name="job_id" class="form-control" value="<?php echo $job_id; ?>" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="Title">Update Job Title</label>
                                <input type="text" name="title" class="form-control" id="exampleInputUsername" value="<?php echo $title; ?>">
                            </div>
                            <div class="form-group">
                                <label for="description">Update Job Description</label>
                                <textarea name="jobdesc" class="form-control" required rows="5"><?php echo $description; ?></textarea>
                            </div>
                            <!-- for keyword -->
                            <div class="form-group">
                                <label for="Job keyword">Update Job Keyword</label>
                                <input type="text" name="keyword" id="key" class="form-control" value="<?php echo $keyword; ?>" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="Country">Update Job Country</label>
                                <select class="form-control" name="country" value="<?php echo $country; ?>">
                                    <?php
                                    $sql1 = "select country from all_jobs";
                                    $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");
                                    if (mysqli_num_rows($result1) > 0) {
                                        while ($row1 = mysqli_fetch_assoc($result1)) {
                                            if ($row1['country']) {
                                                $selected = "selected";
                                            } else {
                                                $selected = "";
                                            }
                                            echo "<option {$selected} value='{$row1['country']}'>{$row1['country']}</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="City">Update Job City</label>
                                <select class="form-control" name="city" value="<?php echo $city; ?>">
                                    <?php
                                    $sql1 = "select city from all_jobs";
                                    $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");
                                    if (mysqli_num_rows($result1) > 0) {
                                        while ($row1 = mysqli_fetch_assoc($result1)) {
                                            if ($row1['city'] == $row['city']) {
                                                $selected = "selected";
                                            } else {
                                                $selected = "";
                                            }

                                            echo "<option {$selected} value='{$row1['city']}'>{$row1['city']}</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="State">Update Job State</label>
                                <select class="form-control" name="state" value="<?php echo $state; ?>">
                                    <?php
                                    $sql1 = "select state from all_jobs";
                                    $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");
                                    if (mysqli_num_rows($result1) > 0) {
                                        while ($row1 = mysqli_fetch_assoc($result1)) {
                                            if ($row1['state'] == $row['state']) {
                                                $selected = "selected";
                                            } else {
                                                $selected = "";
                                            }
                                            echo "<option {$selected} value='{$row1['state']}'>{$row1['state']}</option>";
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="Job Category">Update Job Category</label>
                                <select name="category" class="form-control" id="cat" value="<?php echo $category; ?>">
                                    <option value="">Select Category</option>
                                    <?php

                                    $sql1 = "select * from job_category";

                                    $result1 = mysqli_query($conn, $sql1) or die("Query Failed.");

                                    if (mysqli_num_rows($result1) > 0) {

                                        while ($row1 = mysqli_fetch_assoc($result1)) {

                                            if ($row['category'] == $row1['category_job']) {
                                                $selected = "selected";
                                            } else {
                                                $selected = "";
                                            }

                                            echo "<option {$selected} value='{$row1['cid']}'>{$row1['category_job']}</option>";
                                        }
                                    }

                                    ?>
                                </select>
                            </div>
                            <!-- <div class="form-group">
                                <label for="">Post image</label>
                                <input type="file" name="new-image">
                                <img  src="upload/post_1.jpg" height="150px">
                                <input type="hidden" name="old-image" value="">
                            </div> -->
                            <input type="submit" name="submit" class="btn btn-primary btn-block" value="Update" />
                        </form>
                        <!-- Form End -->
                <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>

<!-- php code block -->
<?php

if (isset($_POST['submit'])) {

    $job_title = mysqli_real_escape_string($conn, $_POST['title']);
    $job_desc = mysqli_real_escape_string($conn, $_POST['jobdesc']);
    $keyword =  mysqli_real_escape_string($conn, $_POST['keyword']);
    $job_country = mysqli_real_escape_string($conn, $_POST['country']);
    $job_state = mysqli_real_escape_string($conn, $_POST['state']);
    $job_city = mysqli_real_escape_string($conn, $_POST['city']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);

    $sql2 = "update all_jobs set job_title = '{$job_title}', job_desc = '{$job_desc}', keyword = '{$keyword}', country = '{$job_country}', 
        state = '{$job_state}', city = '{$job_city}', category = '{$category}' where job_id = {$edit_id}";

    $result2 = mysqli_query($conn, $sql2) or die("Query Failed.");

    if ($result2) {
        echo "<script style='color:green; text-align:center;'>alert('Record Successfully Updated !!!')</script>";
        // header("location: {$hostname}/admin/job_create.php"); 
    } else {
        echo "<div style='color:red; text-align:center; margin:10px 0;'>Record Can't Update !!</div>";
    }
}

mysqli_close($conn);

?>