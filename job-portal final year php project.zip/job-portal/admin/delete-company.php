<?php

include 'config.php';

session_start();
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}

$del_id = $_GET['comp-del'];

$sql = "delete from company where comp_id = {$del_id}";

$result = mysqli_query($conn, $sql) or die("Query Failed.");

if($result){

	header("location: {$hostname}/admin/company.php");
}else{

	echo "<p style='color:red; text-align:center; margin:10px 0;'>Can't Delete Record.</p>";
}

?>