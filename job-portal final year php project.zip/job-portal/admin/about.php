<?php include "include/header.php"; 
$page='about';
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">About</h1>
            </div>
            <div class="col-md-2">
                <a class="add-new" href="add-about.php">add about page</a>
            </div>
            <div class="col-md-12">
                <table class="content-table">
                    <thead>
                        <th>S.No.</th>
                        <th>About Title</th>
                        <th>About Description</th>
                        <!-- <th>About image</th> -->
                        <th>Edit</th>
                        <th>Delete</th>
                        <!-- <th>Action</th> -->
                    </thead>
                    <tbody>
                        <?php

                        include 'config.php';

                        $limit = 3;

                        if (isset($_GET['page'])) {
                            $page = $_GET['page'];
                        } else {
                            $page = 1;
                        }

                        $offset = ($page - 1) * $limit;

                        $sql = "select * from about order by about_id desc limit {$offset},{$limit}";

                        $result = mysqli_query($conn, $sql) or die("Query Failed.");

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {

                                $about_id = $row['about_id'];
                                $about_title = $row['about_title'];
                                $description = $row['about_desc'];
                                // $image = $row['about_image'];

                        ?>
                                <tr>
                                    <td class='id'><?php echo $about_id; ?></td>
                                    <td><?php echo $about_title; ?></td>
                                    <td><?php echo $description; ?></td>
                                    <!-- <td><?php echo $image; ?></td> -->
                                    <td>
                                        <a href="update-about.php?abt-edt=<?php echo $about_id; ?>" class="mr-4 text-info"><i class='fa fa-edit'></i></a>
                                    </td>
                                    <td>
                                        <a href="delete-about.php?abt-del=<?php echo $about_id; ?>" class="text-danger"><i class='fa fa-trash'></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <!-- php block -->
                <?php

                $query = "select * from about";

                $result_query = mysqli_query($conn, $query) or die("Query Failed !!");

                if (mysqli_num_rows($result_query) > 0) {

                    $total_record = mysqli_num_rows($result_query);

                    // $limit = 3;

                    $total_pages = ceil($total_record / $limit);

                    echo "<ul class='pagination admin-pagination'>";

                    if ($page > 1) {

                        echo '<li><a href="about.php?page=' . ($page - 1) . '">Prev</a></li>';
                    }

                    for ($i = 1; $i <= $total_pages; $i++) {

                        if ($i == $page) {
                            $active = "active";
                        } else {
                            $active = "";
                        }

                        echo '<li class=' . $active . '><a href="about.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    if ($page < $total_pages) {

                        echo '<li><a href="about.php?page=' . ($page + 1) . '">Next</a></li>';
                    }

                    echo "</ul>";
                }

                ?>
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>