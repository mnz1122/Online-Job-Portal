<?php include "include/header.php";
$page='apply';
error_reporting(0);
// if($_SESSION['admin_type'] == '0'){
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">All Applied Job</h1>
            </div>
            <!-- <div class="col-md-2">
                  <a class="add-new" href="add-job.php">add job</a>
              </div> -->
            <div class="col-md-12">
                <table class="content-table">
                    <thead>
                        <th>S.No</th>
                        <th>Job Title</th>
                        <!-- <th>First Name</th>
                            <th>Last Name</th> -->
                        <th>Job Description</th>
                        <th>Job Seeker Name</th>
                        <th>Job Seeker Email</th>
                        <th>File</th>
                        <th>Mobile Number</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <!-- php code -->
                        <?php

                        include 'config.php';

                        $limit = 3;

                        if (isset($_GET['page'])) {
                            $page = $_GET['page'];
                        } else {
                            $page = 1;
                        }

                        $offset = ($page - 1) * $limit;

                        $job_id = 1;
                        if ($_SESSION['admin_type'] == '1') {
                            $sql = "select apply_id, job_title, apply_firstname, apply_lastname, apply_seekername, job_desc, file, mobile 
                                from apply_job left join all_jobs on apply_job.job_id = all_jobs.job_id  
                                order by apply_id desc limit {$offset},{$limit}";
                        } elseif ($_SESSION['admin_type'] == '0') {
                            $sql = "select apply_id, job_title, apply_firstname, apply_lastname, apply_seekername, job_desc, file, mobile 
                                    from apply_job left join all_jobs on apply_job.job_id = all_jobs.job_id
                                    where customer_email = '{$_SESSION['email']}'";
                        }

                        $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {

                                $job = $row['apply_id'];
                                $title = $row['job_title'];
                                $description = $row['job_desc'];
                                $first_name = $row['apply_firstname'];
                                $last_name = $row['apply_lastname'];
                                $seeker = $row['apply_seekername'];
                                $file = $row['file'];
                                $mobile = $row['mobile'];
                        ?>
                                <tr>
                                    <td><?php echo $job; ?></td>
                                    <td><?php echo $title; ?></td>
                                    <td><?php echo $description; ?></td>
                                    <td><?php echo $first_name; ?> <?php echo $last_name; ?></td>
                                    <td><?php echo $seeker; ?></td>
                                    <td><a href="images/<?php echo $file; ?>">Download Resume File</a></td>
                                    <td><?php echo $mobile; ?></td>
                                    <td>
                                        <a href="view-apply-job.php?job-view=<?php echo $job; ?>" class="mr-4 text-info pl-4"><i class='fas fa-eye fa-lg'></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        $job_id++;
                        ?>
                    </tbody>
                </table>
                <!-- php block -->
                <?php

                if ($_SESSION['admin_type'] == '1') {

                    $query = "select * from apply_job";
                } elseif ($_SESSION['admin_type'] == '0') {

                    $query = "select * from apply_job left join all_jobs on apply_job.job_id = all_jobs.job_id
                    where customer_email = '{$_SESSION['email']}'";
                }

                $result_query = mysqli_query($conn, $query) or die("Query Failed !!");

                if (mysqli_num_rows($result_query) > 0) {

                    $total_record = mysqli_num_rows($result_query);

                    // $limit = 3;

                    $total_pages = ceil($total_record / $limit);

                    echo "<ul class='pagination admin-pagination'>";

                    if ($page > 1) {

                        echo '<li><a href="apply_job.php?page=' . ($page - 1) . '">Prev</a></li>';
                    }

                    for ($i = 1; $i <= $total_pages; $i++) {

                        if ($i == $page) {
                            $active = "active";
                        } else {
                            $active = "";
                        }

                        echo '<li class=' . $active . '><a href="apply_job.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    if ($page < $total_pages) {

                        echo '<li><a href="apply_job.php?page=' . ($page + 1) . '">Next</a></li>';
                    }

                    echo "</ul>";
                }

                ?>
                <!-- <ul class='pagination admin-pagination'>
                      <li class="active"><a>1</a></li>
                      <li><a>2</a></li>
                      <li><a>3</a></li>
                  </ul> -->
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>