<?php 
include 'config.php'; 
session_start();
if(!isset($_SESSION['email'])){
    header("location: {$hostname}/admin/login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>ADMIN Panel</title>
        <!-- Bootstrap -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        <!-- bootstrap file -->
        <!-- <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> -->
        <!-- Font Awesome Icon -->
        <link rel="stylesheet" href="../css/font-awesome.css">
        <!-- Custom stlylesheet -->
        <link rel="stylesheet" href="css/style.css">
        <!-- for icons -->
        <link rel="stylesheet" href="css/all.css">
        <!-- home page css -->
        <link rel="stylesheet" href="css/home.css">
    </head>
    <body>
        <!-- HEADER -->
        <div id="header-admin">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <!-- LOGO -->
                    <div class="col-md-3">
                        <a href="job-create.php"><img class="logo" src="images/logo2.png"></a>
                    </div>
                    <!-- /LOGO -->
                      <!-- LOG-Out -->
                    <div class="col-md-offset-6  col-md-2">
                        <a href="logout.php" class="admin-logout" >wellcome <?php echo $_SESSION['email']; ?> logout</a>
                    </div>
                    <!-- /LOGO-Out -->
                </div>
            </div>
        </div>
        <!-- /HEADER -->
        <!-- Menu Bar -->
        <div id="admin-menubar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                       <ul class="admin-menu">
                            <li class="<?php if($page == 'home'){echo 'active';} ?>">
                                <a href="home.php">Home Page</a>
                            </li>
                            <li class="<?php if($page == 'job'){echo 'active';} ?>">
                                <a href="job-create.php">Create Job</a>
                            </li>
                            <li class="<?php if($page == 'company'){echo 'active';} ?>">
                                <a href="company.php">Company</a>
                            </li>
                            <li class="<?php if($page == 'apply '){echo 'active';} ?>"> 
                                <a href="apply_job.php">Apply Job</a>
                            </li>
                            <?php 
                                if($_SESSION['admin_type'] == '1'){
                            ?>
                            <li class="<?php if($page == 'customer '){echo 'active';} ?>"> 
                                <a href="customer.php">Customer</a>
                            </li>
                            <li class="<?php if($page == 'category '){echo 'active';} ?>"> 
                                <a href="category.php">Category</a>
                            </li>
                            <li class="<?php if($page == 'report '){echo 'active';} ?>"> 
                                <a href="all_report.php">Report</a>
                            </li>
                            <li class="<?php if($page == 'about '){echo 'active';} ?>"> 
                                <a href="about.php">About</a>
                            </li>
                            <li class="<?php if($page == 'contact '){echo 'active';} ?>"> 
                                <a href="contact.php">Contact</a>
                            </li>
                            <?php
                                }
                            ?>    
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Menu Bar -->
