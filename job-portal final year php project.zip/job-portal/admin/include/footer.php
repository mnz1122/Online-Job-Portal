<!-- Footer -->
<div id ="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <span>© Copyright 2023 Job Portal | Powered by <a href="http://yahoobaba.net/">M.Nawaz</a></span>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>
</html>
