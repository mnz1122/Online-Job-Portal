<?php include "include/header.php"; ?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Add New Job</h1>
            </div>
            <div class="col-md-offset-3 col-md-6">
                <!-- Form -->
                <form action="insert-job.php" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="job_title">Enter Job Title</label>
                        <input type="text" name="job_title" class="form-control" autocomplete="off" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Enter Job Description</label>
                        <textarea name="job_desc" class="form-control" rows="5" required></textarea>
                    </div>
                    <!-- <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" name="email" class="form-control" placeholder="email" required>
                      </div> -->
                    <div class="form-group">
                        <label for="Job Keyword">Enter Job Keyword</label>
                        <input type="text" name="keyword" id="key" class="form-control" placeholder="Enter Job Keyword" required>
                    </div>
                    <div class="form-group">
                        <label for="city">City</label>
                        <select name="add-city" class="form-control">
                            <option value="" selected> Select City</option>
                            <option value="peshawer">Peshawer</option>
                            <option value="shangai">Shangai</option>
                            <option value="istanbol">Istanbol</option>
                            <option value="dubai">Dubai</option>
                            <option value="london">London</option>
                            <option value="new york">New York</option>
                            <option value="moscow">Moscow</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="add-country">Country</label>
                        <select name="add-country" class="form-control">
                            <option value="" selected> Select Country</option>
                            <option value="Pakistan">Pakistan</option>
                            <option value="China">China</option>
                            <option value="Turkey">Turkey</option>
                            <option value="UAE">UAE</option>
                            <option value="England">England</option>
                            <option value="America">America</option>
                            <option value="Russia">Russia</option>
                        </select> 
                        <!-- <select class="selectpicker countrypicker" data-flag="true" ></select> -->
                    </div>
                    <div class="form-group">
                        <label for="add-state">State</label>
                        <select name="add-state" class="form-control">
                            <option value="" selected> Select State</option>
                            <option value="pakistan">Pakistan</option>
                            <option value="china">China</option>
                            <option value="turkey">Turkey</option>
                            <option value="dubai">Dubai</option>
                            <option value="england">England</option>
                            <option value="california">California</option>
                            <option value="russia">Russia</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="Job Category">Enter Job Category</label>
                        <select name="add-category" class="form-control" id="cat">
                            <option value="">Select Category</option>
                            <?php

                            $sql = "select * from job_category";

                            $result = mysqli_query($conn, $sql) or die("Query Failed.");

                            if (mysqli_num_rows($result) > 0) {

                                while ($row = mysqli_fetch_assoc($result)) {

                                    echo "<option value='{$row['cid']}'>{$row['category_job']}</option>";
                                }
                            }

                            ?>
                        </select>
                    </div>
                    <!-- <div class="form-group">
                        <label for="Job Company">Enter Job Company</label>
                        <select name="add-company" class="form-control" id="cat">
                            <option value="">Select Company</option>
                            <?php

                            $sql = "select comp_id, comp_name from company";

                            $result = mysqli_query($conn, $sql) or die("Query Failed.");

                            if (mysqli_num_rows($result) > 0) {

                                while ($row = mysqli_fetch_assoc($result)) {

                                    echo "<option value='{$row['comp_id']}'>{$row['comp_name']}</option>";
                                }
                            }

                            ?>
                        </select>
                    </div> -->
                    <!-- <div class="form-group">
                          <label for="exampleInputPassword1">Post image</label>
                          <input type="file" name="fileToUpload" required>
                      </div> -->
                    <input type="submit" name="submit" class="btn btn-primary btn-block" value="Save" required />
                </form>
                <!--/Form -->
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>