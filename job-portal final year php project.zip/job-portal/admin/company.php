<?php include "include/header.php";
$page='company';
// session_start();
// if($_SESSION['admin_type'] == '0'){
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">All Companies</h1>
            </div>
            <div class="col-md-2">
                <a class="add-new" href="add-company.php">add company
                </a>
            </div>
            <div class="col-md-12">
                <table class="content-table">
                    <thead>
                        <th>S.No</th>
                        <th>Company Name</th>
                        <th>Description</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        <!-- <th>Action</th> -->
                    <tbody>
                        <?php

                        include 'config.php';

                        $limit = 3;

                        if (isset($_GET['page'])) {
                            $page = $_GET['page'];
                        } else {
                            $page = 1;
                        }

                        $offset = ($page - 1) * $limit;

                        if ($_SESSION['admin_type'] == '1') {

                            $sql = "select * from company order by comp_id desc limit {$offset}, {$limit}";

                        } elseif ($_SESSION['admin_type'] == '0') {
                            
                            $sql = "select * from company where comp_admin = '{$_SESSION['email']}' 
                                    order by comp_id desc limit {$offset}, {$limit}";
                        }

                        $result = mysqli_query($conn, $sql) or die("Query Failed.");

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {

                                $comp_id = $row['comp_id'];
                                $comp_name = $row['comp_name'];
                                $description = $row['comp_desc'];
                        ?>
                                <tr>
                                    <td class='id'><?php echo $comp_id; ?></td>
                                    <td><?php echo $comp_name; ?></td>
                                    <td><?php echo $description; ?></td>
                                    <td>
                                        <a href="update-company.php?comp-edt=<?php echo $comp_id; ?>" class="mr-4 text-info"><i class='fa fa-edit'></i></a>
                                    </td>
                                    <td>
                                        <a href="delete-company.php?comp-del=<?php echo $comp_id; ?>" class="text-danger"><i class='fa fa-trash'></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <!-- php block -->
                <?php

                if($_SESSION['admin_type'] == '1'){
                    $query = "select * from company";
                }elseif($_SESSION['admin_type'] == '0'){
                    $query = "select * from company where comp_admin = '{$_SESSION['email']}'";
                }

                $result_query = mysqli_query($conn, $query) or die("Query Failed !!");

                if (mysqli_num_rows($result_query) > 0) {

                    $total_record = mysqli_num_rows($result_query);

                    // $limit = 3;

                    $total_pages = ceil($total_record / $limit);

                    echo "<ul class='pagination admin-pagination'>";

                    if ($page > 1) {

                        echo '<li><a href="company.php?page=' . ($page - 1) . '">Prev</a></li>';
                    }

                    for ($i = 1; $i <= $total_pages; $i++) {

                        if ($i == $page) {
                            $active = "active";
                        } else {
                            $active = "";
                        }

                        echo '<li class=' . $active . '><a href="company.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    if ($page < $total_pages) {

                        echo '<li><a href="company.php?page=' . ($page + 1) . '">Next</a></li>';
                    }

                    echo "</ul>";
                }

                ?>
                <!-- <ul class='pagination admin-pagination'>
                    <li class="active"><a>1</a></li>
                    <li><a>2</a></li>
                    <li><a>3</a></li>
                </ul> -->
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>