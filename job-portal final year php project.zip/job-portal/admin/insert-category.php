<?php

//authentication
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}

include 'config.php';

$category_name = mysqli_real_escape_string($conn, $_POST['cat_name']);
// form validation
if($category_name == ""){
    echo '<script>alert("Please Enter The Category Name !!!")</script>';
    return false;
}

$description = mysqli_real_escape_string($conn, $_POST['description']);
if($description == ""){
    echo '<script>alert("Please Enter The Category Description !!")</script>';
    return false;
}

$sql = "insert into job_category(category_job, cat_desc) values ('{$category_name}', '{$description}')";

$result = mysqli_query($conn, $sql) or die("Query Failed !!");

if($result){
    header("Location: {$hostname}/admin/category.php");
}else{
    echo '<div class="alert alert-danger">Some error please try again !!!</div>'; 
}

mysqli_close($conn);
 
?>