<?php include "include/header.php";

error_reporting(0);
#authentication
// if ($_SESSION['admin_type'] == '0') {
//     header("location: {$hostname}/admin/job-create.php");
// }

?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">Send E-Mail</h1>
            </div><br><br>
            <!-- php code -->
            <?php

            include 'config.php';

            $job_id = $_GET['send-id'];
            $sql = "select job_title, apply_firstname, apply_lastname, apply_seekername, customer_email, job_desc, mobile from 
                    apply_job left join all_jobs on apply_job.job_id = all_jobs.job_id  
                    where apply_id = {$job_id}";

            $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

            if (mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_assoc($result)) {

                    $first_name = $row['apply_firstname'];
                    $last_name = $row['apply_lastname'];
                    $job_seekeremail = $row['apply_seekername'];
                    $customer_email = $row['customer_email'];
            ?>
                    <div class="container">
                        <form action="phpmailer.php" method="POST" style="border:1px solid lightgrey; background: #eee; padding:25px; width:65%; margin:30px auto 30px auto;">
                            <h2><?php echo strtoupper($first_name); ?> <?php echo strtoupper($last_name); ?></h2>
                            <hr>
                            <input type="hidden" name="id" id="id" value="<?php echo $job_id; ?>">
                            <div class="form-group">
                                <label for="To"><b>From :</b></label>
                                <input type="email" name="from" id="from" class="form-control" value="<?php echo $customer_email; ?>" placeholder="Type Email Of Job Provider">
                            </div>
                            <div class="form-group">
                                <label for="To"><b>To :</b></label>
                                <input type="email" name="to" id="to" class="form-control" value="<?php echo $job_seekeremail; ?>">
                            </div>
                            <!-- <div class="form-group">
                        <label for="To">Subject :</label>
                        <input type="email" name="to" id="to" class="form-control" value="">
                    </div> -->
                            <div class="form-group">
                                <label for="To"><b>Compose Email :</b></label>
                                <textarea name="body" id="body" class="form-control" row="10" col="20">
                            DEAR <?php echo strtoupper($first_name); ?> <?php echo strtoupper($last_name); ?>
                        </textarea>
                            </div>
                            <input type="submit" name="submit" class="btn btn-success btn-block" value="Send">
                        </form>
                    </div>
            <?php
                }
            }

            ?>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>