<?php include "include/header.php"; 
//authentication
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="admin-heading"> Update Category</h1>
              </div>
              <div class="col-md-offset-3 col-md-6">
                    <!-- php code block start-->
                    <?php

                    include 'config.php';

                    $edit_id = $_GET['cat-edt'];

                    $sql = "select * from job_category where cid = {$edit_id}";

                    $result = mysqli_query($conn, $sql) or die("Query Failed!!");

                    if (mysqli_num_rows($result) > 0) {

                        while ($row = mysqli_fetch_assoc($result)) {

                    ?>
                            <!-- form start -->
                            <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" style="margin:5%; padding:4%;" name="category-form" id="customer-form">
                                <div class="form-group">
                                    <input type="hidden" name="cid" class="form-control" id="" value="<?php echo $row['cid']; ?>" placeholder="">
                                </div>
                                <div class="form-group">
                                    <label for="Category">Update Category Name</label>
                                    <input type="text" name="category" id="" class="form-control" value="<?php echo $row['category_job']; ?>" placeholder="Update Category Name">
                                </div>
                                <div class="form-group">
                                    <label for="Description">Update Category Description</label>
                                    <textarea name="description" id="description" class="form-control" cols="20" rows="10"><?php echo $row['cat_desc']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <input type="submit" name="update" value="update" id="update" class="btn btn-success btn-block">
                                </div>
                            </form>
                    <?php
                        }
                    }
                    ?>
                    <!-- form end -->
                </div>
              </div>
            </div>
          </div>
<?php include "include/footer.php"; ?>

<!-- php block code -->
<?php

#now update the data in database
if (isset($_POST['update'])) {

    // $edit_id = $_GET['edit'];

    $category = mysqli_real_escape_string($conn, $_POST['category']);

    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql1 = "update job_category set category_job = '{$category}', cat_desc = '{$description}' where cid = {$edit_id}";

    $result1 = mysqli_query($conn, $sql1) or die("Query Failed!!!");

    if ($result1) {

        echo "<script style='color:green; text-align:center;'>alert('Record Successfully Updated !!!')</script>";
        // header("location: {$hostname}/admin/category.php");
    } else {

        echo "<script>alert('Record Can't Updated Please try again !!!')</script>";
    }
}

?>
