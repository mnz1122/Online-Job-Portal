<?php
session_start();
if(isset($_SESSION['email'])){
  header("location: {$hostname}/admin/job-create.php");
}
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <link rel="stylesheet" href="css/style1.css">
</head>

<body>

  <!-- php block -->
  <?php

  include 'config.php';

  if (isset($_POST['submit'])) {

    $email = $_POST['email'];

    $pass = $_POST['password'];
    
    $email_search = "select * from admin_login where admin_email = '{$email}'";

    $result = mysqli_query($conn, $email_search) or die("Query Failed !!");

    $count = mysqli_num_rows($result);

    if ($count > 0) {

      $row = mysqli_fetch_assoc($result);

      $db_password = $row['admin_password'];

      $pass_decode = password_verify($pass, $db_password);

      if ($pass_decode) {

        session_start();
        $_SESSION['admin_id'] = $row['admin_id'];
        $_SESSION['email'] = $row['admin_email'];
        $_SESSION['admin_type'] = $row['admin_type'];

        header("location: {$hostname}/admin/job-create.php");
        // die();
      } else {

        echo "<script>alert('Please enter correct password !!')</script>";
      }
    } else {

      echo "<script>alert('You entered invalid Email !!')</script>";
    }
  }

  ?>

  <div class="container">
    <img src="images/logo2.png" class="img-fluid rounded" style="margin-left:70px;">
    <form method="POST" action="<?php $_SERVER['PHP_SELF']; ?>" id="login-form">
      <h1>Login</h1>
      <label for="email">Email</label>
      <input type="email" name="email" id="email" placeholder="Enter Your Email" required>
      <label for="password">Password</label>
      <input type="password" name="password" id="admin-password" placeholder="Enter Your Password" required>
      <!-- <input type="checkbox" name="remember" id="remember"> -->
      <!-- <label for="remember">Remember me</label> -->
      <input type="submit" name="submit" value="Login"><br>
      <a href="login.php" style="text-align:center; font-size:18px; font-weight:500; letter-spacing:1px;">Cancel</a>
      <!-- <div class="forgot-password">
        <a href="#">Forgot password?</a>
      </div> -->
    </form>
  </div>
</body>

</html>