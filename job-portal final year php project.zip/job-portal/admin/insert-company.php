<?php

  include 'config.php';

  session_start();
  if($_SESSION['admin_type'] == '0'){
      header("location: {$hostname}/admin/job-create.php");
  }

  $company = mysqli_real_escape_string($conn, $_POST['comp']);

  $description = mysqli_real_escape_string($conn, $_POST['compdesc']);

  $comp_admin = mysqli_real_escape_string($conn, $_POST['comp-admin']);

  $sql = "insert into company (comp_name, comp_desc, comp_admin) values ('{$company}', '{$description}', '{$comp_admin}')";

  $result = mysqli_query($conn, $sql) or die("Query Failed !!");

  if($result){

        header("location: {$hostname}/admin/company.php");
  }else{

   echo "<div style='color:red; text-align:center; margin:10px, 0;'>Record Not Inserted. Please try again !!</div>";
}

?>