<?php

session_start();
//authentication
// if($_SESSION['admin_type'] == '0'){
//     header("location: {$hostname}/admin/job-create.php");
// }

include 'config.php';

$rej_id = $_GET['rej-conid'];

$rej_query = "delete from contact where contact_id = {$rej_id}";

$rej_store = mysqli_query($conn, $rej_query) or die("Query Failed !!");

if($rej_store){
    // echo "Data Has Been Successfully Rejected !!";
    // header("location: {$hostname}/admin/apply-job.php");
    echo "<script>
            window.setTimeout(function(){
                window.location.href = '{$hostname}/admin/contact.php';
                }, 5000);
         </script>";
}else{
    echo "Data Not Rejected. Plaese Try Again !!";
}

mysqli_close($conn);

?>