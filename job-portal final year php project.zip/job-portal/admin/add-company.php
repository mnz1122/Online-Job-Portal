<?php include "include/header.php"; 
// if($_SESSION['admin_type'] == '0'){
//     header("location: {$hostname}/admin/job-create.php");
// }
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Add New Company</h1>
            </div>
            <div class="col-md-offset-3 col-md-6">
                <!-- Form Start -->
                <form action="insert-company.php" method="POST" autocomplete="off">
                    <div class="form-group">
                        <label>Company Name</label>
                        <input type="text" name="comp" class="form-control" placeholder="Company Name" required>
                    </div>
                    <div class="form-group">
                        <label for="description"> Description</label>
                        <textarea name="compdesc" class="form-control" rows="5" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="comp admin">Enter Company Admin</label>
                        <select name="comp-admin" id="company" class="form-control" required>
                        <option value="">Select Company Email</option>
                            <?php

                            include 'config.php';

                            // if($_SESSION['admin_type'] == '1'){

                                $sql = "select * from admin_login where admin_type = '0'";
                            // }elseif($_SESSION['admin_type'] == '0'){

                            //     $sql = "select * from admin_login where admin_type = '0' and admin_email = '{$_SESSION['email']}'";
                            // }

                            $result = mysqli_query($conn, $sql) or die("Query Failed.");

                            if (mysqli_num_rows($result) > 0) {

                                while ($row = mysqli_fetch_assoc($result)) {
                                    echo "<option value='{$row['admin_email']}'>{$row['admin_email']}</option>";
                                }
                            }

                            ?>
                        </select>
                    </div>
                    <input type="submit" name="save" class="btn btn-info btn-block" value="Save" required />
                </form>
                <!-- /Form End -->
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>