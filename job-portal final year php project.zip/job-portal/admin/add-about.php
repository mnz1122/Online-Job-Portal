<?php include "include/header.php"; 
if($_SESSION['admin_type'] == '0'){
    header("location: {$hostname}/admin/job-create.php");
}
?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="admin-heading">Add About Details</h1>
            </div>
            <div class="col-md-offset-3 col-md-6">
                <!-- Form Start -->
                <form action="insert-about.php" method="POST" enctype="multipart/form-data" autocomplete="off">
                    <div class="form-group">
                        <label for="title">About Title</label>
                        <input type="text" name="title" class="form-control" placeholder="Enter Title" required>
                    </div>
                    <div class="form-group">
                        <label for="description">About Description</label>
                        <textarea name="desc" id="desc" class="form-control" cols="20" rows="10"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="file">About Image</label>
                        <input type="file" name="fileToUpload" class="form-control" placeholder="Image" required>
                    </div>
                    <input type="submit" name="save" class="btn btn-primary btn-block" value="Save" required />
                </form>
                <!-- Form End-->
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>