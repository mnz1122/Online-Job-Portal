<?php include "include/header.php"; $page='job';?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">All Jobs</h1>
            </div>
            <div class="col-md-2">
                <a class="add-new" href="add-job.php">add job</a>
            </div>
            <div class="col-md-12">
                <table class="content-table">
                    <thead>
                        <th>S.No.</th>
                        <th>Job Title</th>
                        <th>Job Description</th>
                        <th>Job Post</th>
                        <th>Job Keyword</th>
                        <!-- <th>Customer Email</th> -->
                        <th>City</th>
                        <th>Country</th>
                        <th>State</th>
                        <th>Job Category</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        <!-- <th>Action</th> -->
                    </thead>
                    <tbody>
                        <?php
                            
                        include 'config.php';

                        $limit = 3;

                        if (isset($_GET['page'])) {
                            $page = $_GET['page'];
                        } else {
                            $page = 1;
                        }

                        $offset = ($page - 1) * $limit;

                        if($_SESSION['admin_type'] == '1'){

                            $sql = "select all_jobs.job_id, all_jobs.job_title, all_jobs.job_desc, all_jobs.customer_email, all_jobs.city, all_jobs.country, 
                                    all_jobs.state, all_jobs.keyword, all_jobs.category, job_category.category_job from all_jobs left join job_category on 
                                    all_jobs.category = job_category.cid 
                                    order by job_id desc limit {$offset},{$limit} "; 

                        }elseif($_SESSION['admin_type'] == '0'){

                            $sql = "select * from all_jobs left join job_category on all_jobs.category = job_category.cid 
                            where customer_email = '{$_SESSION['email']}'  
                            order by job_id desc limit {$offset},{$limit} ";

                        }

                        // $sql = "select * from all_jobs where customer_email = '{$_SESSION['email']}' 
                        //         order by job_id desc limit {$offset},{$limit} ";

                        $result = mysqli_query($conn, $sql) or die("Query Failed.");

                        if (mysqli_num_rows($result) > 0) {

                            while ($row = mysqli_fetch_assoc($result)) {

                                $job_id = $row['job_id'];
                                $title = $row['job_title'];
                                $description = $row['job_desc'];
                                $cust_email = $row['customer_email'];
                                $keyword = $row['keyword'];
                                $city = $row['city'];
                                $country = $row['country'];
                                $state = $row['state'];
                                $category = $row['category_job'];
                        ?>
                                <tr>
                                    <td class='id'><?php echo $job_id; ?></td>
                                    <td><?php echo $title; ?></td>
                                    <td><?php echo $description; ?></td>
                                    <td><?php echo $cust_email; ?></td>
                                    <td><?php echo $keyword; ?></td>
                                    <td><?php echo $city; ?></td>
                                    <td><?php echo $country; ?></td>
                                    <td><?php echo $state; ?></td>
                                    <td><?php echo $category; ?></td>
                                    <td>
                                        <a href="update-job.php?job-edt=<?php echo $job_id; ?>" class="p-3 text-info"><i class='fa fa-edit'></i></a>
                                    </td>
                                    <td>
                                        <a href="delete-job.php?job-del=<?php echo $job_id; ?>&cat-id=<?php echo $row['category']; ?>" class="text-danger"><i class='fa fa-trash'></i></a>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
                <!-- php block -->
                <?php

                if($_SESSION['admin_type'] == '1'){
                    $query = "select * from all_jobs";
                }elseif($_SESSION['admin_type'] == '0'){
                    $query = "select * from all_jobs where customer_email = '{$_SESSION['email']}'";
                }

                $result_query = mysqli_query($conn, $query) or die("Query Failed !!");

                if (mysqli_num_rows($result_query) > 0) {

                    $total_record = mysqli_num_rows($result_query);

                    // $limit = 3;

                    $total_pages = ceil($total_record / $limit);

                    echo "<ul class='pagination admin-pagination'>";

                    if ($page > 1) {

                        echo '<li><a href="job-create.php?page=' . ($page - 1) . '">Prev</a></li>';
                    }

                    for ($i = 1; $i <= $total_pages; $i++) {

                        if ($i == $page) {
                            $active = "active";
                        } else {
                            $active = "";
                        }

                        echo '<li class=' . $active . '><a href="job-create.php?page=' . $i . '">' . $i . '</a></li>';
                    }

                    if ($page < $total_pages) {

                        echo '<li><a href="job-create.php?page=' . ($page + 1) . '">Next</a></li>';
                    }

                    echo "</ul>";
                }

                ?>
            </div>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>