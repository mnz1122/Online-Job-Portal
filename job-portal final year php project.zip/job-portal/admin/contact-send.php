<?php include "include/header.php";

error_reporting(0);
#authentication
// if ($_SESSION['admin_type'] == '0') {
//     header("location: {$hostname}/admin/job-create.php");
// }

?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">Send E-Mail To Contact</h1>
            </div><br><br>
            <!-- php code -->
            <?php if($_SESSION['admin_type'] == '1'){
                $con_email = "select admin_email from admin_login where admin_email = '{$_SESSION['email']}'";
                $store_query = mysqli_query($conn, $con_email) or die("Query Failed.");
                if(mysqli_num_rows($store_query) > 0){
                    while($row1 = mysqli_fetch_assoc($store_query)){
                        $get_admin_emial = $row1['admin_email'];
                    }
                }
            } 
            ?>

            <?php

            include 'config.php';

            $con_id = $_GET['send-conid'];
            $sql = "select * from contact where contact_id = {$con_id}";

            $result = mysqli_query($conn, $sql) or die("Query Failed !!!");

            if (mysqli_num_rows($result) > 0) {

                while ($row = mysqli_fetch_assoc($result)) {
                    $contact_name = $row['contact_username'];
                    $contact_email = $row['contact_useremail'];
                    $contact_subject = $row['contact_subject'];
                    $contact_message = $row['contact_message'];
            ?>
                    <div class="container">
                        <form action="phpmailer.php" method="POST" style="border:1px solid lightgrey; background: #eee; padding:25px; width:65%; margin:30px auto 30px auto;">
                            <h2><?php echo strtoupper($contact_name); ?></h2>
                            <hr>
                            <input type="hidden" name="id" id="id" value="<?php echo $con_id; ?>">
                            <div class="form-group">
                                <label for="To"><b>From :</b></label>
                                <input type="email" name="from" id="from" class="form-control" value="<?php echo $get_admin_emial; ?>" placeholder="">
                            </div>
                            <div class="form-group">
                                <label for="To"><b>To :</b></label>
                                <input type="email" name="to" id="to" class="form-control" value="<?php echo $contact_email; ?>">
                            </div>
                            <div class="form-group">
                                <label for="To">Subject :</label>
                                <input type="text" name="suject" id="subject" class="form-control" value="<?php echo $contact_subject; ?>">
                            </div>
                            <div class="form-group">
                                <label for="To"><b>Compose Email :</b></label>
                                <textarea name="body" id="body" class="form-control" row="10" col="20">
                                     DEAR <?php echo strtoupper($contact_name); ?>
                                </textarea>
                            </div>
                            <input type="submit" name="submit" class="btn btn-success btn-block" value="Send">
                        </form>
                    </div>
            <?php
                }
            }

            ?>
        </div>
    </div>
</div>
<?php include "include/footer.php"; ?>