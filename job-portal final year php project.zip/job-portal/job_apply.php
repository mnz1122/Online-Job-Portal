<?php

include 'db_config.php';

if(isset($_POST['submit'])){

    $apply_id = mysqli_real_escape_string($conn, $_POST['job_id']);
    $seeker_name = mysqli_real_escape_string($conn, $_POST['apply_seekername']);

    $first_name = mysqli_real_escape_string($conn, $_POST['fname']);
    if($first_name == ""){
        echo '<script>alert("Please Enter The first name !!!")</script>';
        return false;
    }
    $last_name = mysqli_real_escape_string($conn, $_POST['lname']);
    if($last_name == ""){
        echo '<script>alert("Please Enter The last name !!!")</script>';
        return false;
    }
    $date_of_birth = mysqli_real_escape_string($conn, $_POST['dob']);
    if($date_of_birth == ""){
        echo '<script>alert("Please Enter The valid data of birth !!!")</script>';
        return false;
    }
    // $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    // if($gender == ""){
    //     echo '<script>alert("Please Enter The valid gender !!!")</script>';
    //     return false;
    // }
    // file information
    $file_name = mysqli_real_escape_string($conn, $_FILES['file']['name']);
    if($file_name == ""){
        echo '<script>alert("Please Enter The file !!!")</script>';
        return false;
    }
    $file_size = mysqli_real_escape_string($conn, $_FILES['file']['size']);
    $file_tmp = mysqli_real_escape_string($conn, $_FILES['file']['tmp_name']);

    move_uploaded_file($file_tmp, 'files/'.$file_name);

    $mobile = mysqli_real_escape_string($conn, $_POST['number']);
    if($file_name == ""){
        echo '<script>alert("Please Enter Mobile Number !!!")</script>';
        return false;
    }

    $date = mysqli_real_escape_string($conn, $_POST['date']);
    if($date == ""){
        echo '<script>alert("Please Enter Date !!!")</script>';
        return false;
    }
    $location = mysqli_real_escape_string($conn, $_POST['loc']);
    if($location == ""){
        echo '<script>alert("Please Enter The valid location !!!")</script>';
        return false;
    }

    // $test = "select * from apply_job where apply_seekername = '{$seeker_name}' and job_id = {$apply_id}";
    
    // $query = mysqli_query($conn, $test) or die("Query Failed !!");

    // if(mysqli_num_rows($query)>0){
    //     header("location: {$hostname}/index.php");
    // }else{

    // }

    $sql = "insert into apply_job (job_id, apply_firstname, apply_lastname, apply_seekername, apply_dob, file, mobile, apply_date, location) 
            values ({$apply_id}, '{$first_name}', '{$last_name}', '{$seeker_name}', '{$date_of_birth}', '{$file_name}', '{$mobile}', '{$date}', '{$location}')"; 

    $result = mysqli_query($conn, $sql) or die("Query Failed !!");

    if($result){
        header("location: {$hostname}/index.php");
    }else{
        echo 'Not Done.';
    }

}

?>