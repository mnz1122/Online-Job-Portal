<?php

include 'include/profile.php';
include 'db_config.php';

$sql_query = "select * from profile where profile_useremail = '{$_SESSION['email']}'";
$result_query = mysqli_query($conn, $sql_query) or die("Query Failed !!");
if(mysqli_num_rows($result_query) > 0){
    while($row = mysqli_fetch_assoc($result_query)){
        $name = $row['profile_name'];
        $email = $row['profile_email'];
        $phone = $row['profile_phone'];
        $dob = $row['profile_dob'];
        $address = $row['profile_address'];
        $img_file = $row['profile_img'];
    }
}

?>
<!-- profile form -->
<div class="container bg-secondary border mt-3 mb-3">
    <img src="profile_img/<?php if(!empty($img_file)){echo $img_file;}else{echo 'user.png';} ?>" style="width:10%; height:0%; margin:10px; margin-left:45%; margin-right:50%;  cursor:pointer;">
    <h2 class="text-white">Job Seeker Profile</h2>
    <form action="add_profile.php" method="post" name="profile_form" id="profile_form" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Enter Your Name:</label>
            <input type="text" name="name" id="name" value="<?php if(!empty($name)) echo $name; ?>" class="form-control" placeholder="Enter Your Name">
        </div>
        <div class="form-group">
            <label for="email">Enter Your Email:</label>
            <input type="email" name="email" id="email" value="<?php if(!empty($email)) echo $email; ?>" class="form-control" placeholder="Enter Your Email">
        </div>
        <div class="form-group">
            <label for="phone">Enter Your Phone:</label>
            <input type="number" name="phone" id="phone" value="<?php if(!empty($phone)) echo $phone; ?>" class="form-control" placeholder="Enter Your Phone Number">
        </div>
        <div class="form-group">
            <label for="address">Enter Your Address:</label>
            <textarea name="address" id="address" col="5" row="10" class="form-control"><?php if(!empty($address)) echo $address; ?></textarea>
        </div>
        <div class="form-group">
            <label for="phone">Enter Your DOB:</label>
            <input type="date" name="dob" id="dob" value="<?php if(!empty($dob)) echo $dob; ?>" class="form-control" placeholder="Enter Your DOB">
        </div>
        <div class="form-group">
            <label for="phone">Upload Profile Image:</label>
            <input type="file" name="img" id="img" class="form-control">
        </div>
        <div class="form-group">
            <input type="submit" name="submit" id="submit" value="Update Profile" class="btn">
        </div>
    </form>
</div>

<section class="ftco-section-parallax">
    <div class="parallax-img d-flex align-items-center">
        <div class="container">
            <div class="row d-flex justify-content-center">
                <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
                    <h2>Subcribe to our Job Portal</h2>
                    <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in</p>
                    <div class="row d-flex justify-content-center mt-4 mb-4">
                        <div class="col-md-8">
                            <form action="#" class="subscribe-form">
                                <div class="form-group d-flex">
                                    <input type="text" class="form-control" placeholder="Enter email address">
                                    <input type="submit" value="Subscribe" class="submit px-3">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'include/footer.php'; ?>
<!-- <script src="js/jquery.js"></script>
<script>
    $(document).ready(function() {
        $('#submit').click(function() {
            // alert('Wellcome');
            var data = ('#profile_form').serialize();
            $.ajax({
                type: "POST",
                url: "update_profile.php",
                data: data,
                success:function(data){
                    alert(data);
                }
            });
        });
    });
</script> -->